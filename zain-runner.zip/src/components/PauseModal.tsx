import React from 'react';
import { Home, Play, RotateCcw, Volume2, VolumeX } from 'lucide-react';

interface PauseModalProps {
  score: number;
  coins: number;
  isMuted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onToggleMute: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  score,
  coins,
  isMuted,
  onResume,
  onRestart,
  onMenu,
  onToggleMute,
}) => {
  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-5"
      style={{ backgroundColor: 'rgba(2, 6, 23, 0.78)' }}
    >
      <div
        className="w-full max-w-sm rounded-3xl border border-white/15 p-6 shadow-2xl flex flex-col gap-5 text-center"
        style={{ backgroundColor: '#0f172a' }}
      >
        <div>
          <h2 className="font-display text-3xl font-bold text-white tracking-wide">
            PAUSED
          </h2>
          <p className="mt-1 text-sm text-slate-300 font-mono-num">
            Score {score.toLocaleString()} · {coins.toLocaleString()} Coins
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={onResume}
            className="min-h-[52px] w-full rounded-2xl bg-gradient-to-b from-sky-400 to-blue-600 text-white font-display font-bold text-xl tracking-wide flex items-center justify-center gap-2.5 shadow-lg active:scale-[0.98] transition-transform cursor-pointer whitespace-nowrap"
          >
            <Play className="w-5 h-5 fill-white shrink-0" />
            <span>Resume</span>
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="min-h-[48px] w-full rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4 shrink-0" />
            <span>Restart Run</span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            className="min-h-[48px] w-full rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform cursor-pointer whitespace-nowrap"
          >
            {isMuted ? <VolumeX className="w-4 h-4 shrink-0" /> : <Volume2 className="w-4 h-4 shrink-0" />}
            <span>{isMuted ? 'Sound: Off' : 'Sound: On'}</span>
          </button>

          <button
            type="button"
            onClick={onMenu}
            className="min-h-[48px] w-full rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform cursor-pointer whitespace-nowrap"
          >
            <Home className="w-4 h-4 shrink-0" />
            <span>Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
