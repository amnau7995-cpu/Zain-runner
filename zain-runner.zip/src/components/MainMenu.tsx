import React from 'react';
import { Play, Trophy, Volume2, VolumeX } from 'lucide-react';

interface MainMenuProps {
  bestScore: number;
  isMuted: boolean;
  isTransitioning: boolean;
  onStart: () => void;
  onToggleMute: () => void;
}

const MENU_PARTICLES = [
  { left: '12%', bottom: '18%', size: 10, delay: '0s', color: '#fde047' },
  { left: '24%', bottom: '10%', size: 8, delay: '1.1s', color: '#38bdf8' },
  { left: '38%', bottom: '22%', size: 12, delay: '2.2s', color: '#fb923c' },
  { left: '64%', bottom: '15%', size: 9, delay: '0.7s', color: '#38bdf8' },
  { left: '78%', bottom: '20%', size: 11, delay: '1.8s', color: '#fde047' },
  { left: '88%', bottom: '12%', size: 7, delay: '2.9s', color: '#fb923c' },
];

export const MainMenu: React.FC<MainMenuProps> = ({
  bestScore,
  isMuted,
  isTransitioning,
  onStart,
  onToggleMute,
}) => {
  return (
    <div
      className={`fixed inset-0 z-20 flex flex-col justify-between px-5 pt-safe pb-safe transition-opacity duration-500 ${
        isTransitioning ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        background:
          'linear-gradient(180deg, rgba(15, 23, 42, 0.55) 0%, rgba(15, 23, 42, 0.08) 45%, rgba(15, 23, 42, 0.68) 100%)',
      }}
    >
      {/* Floating ambient particles */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        {MENU_PARTICLES.map((p, idx) => (
          <span
            key={idx}
            className="animate-particle-rise absolute rounded-full"
            style={{
              left: p.left,
              bottom: p.bottom,
              width: p.size,
              height: p.size,
              backgroundColor: p.color,
              animationDelay: p.delay,
              boxShadow: `0 0 12px ${p.color}`,
            }}
          />
        ))}
      </div>

      {/* Top Bar: Best Score & Sound Toggle */}
      <div className="relative z-10 flex items-center justify-between gap-4">
        <div
          className="flex items-center gap-2.5 rounded-2xl px-4 py-2.5 border border-white/15 shadow-lg"
          style={{ backgroundColor: 'rgba(15, 23, 42, 0.84)' }}
        >
          <Trophy className="w-5 h-5 text-amber-400 shrink-0" />
          <div className="flex flex-col leading-tight">
            <span className="text-[11px] font-semibold text-slate-300">Best Score</span>
            <span className="font-mono-num text-base font-bold text-white">
              {bestScore.toLocaleString()}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={onToggleMute}
          aria-label={isMuted ? 'Unmute sound effects' : 'Mute sound effects'}
          className="min-h-[46px] min-w-[46px] flex items-center justify-center rounded-2xl border border-white/15 text-white shadow-lg active:scale-95 transition-transform cursor-pointer"
          style={{ backgroundColor: 'rgba(15, 23, 42, 0.84)' }}
        >
          {isMuted ? <VolumeX className="w-5 h-5 text-slate-300" /> : <Volume2 className="w-5 h-5 text-sky-400" />}
        </button>
      </div>

      {/* Center Hero Title — Positioned high enough to keep the 3D runner visible below */}
      <div className="relative z-10 flex flex-col items-center text-center mt-2 mb-auto pt-4">
        <div className="animate-menu-float flex flex-col items-center">
          <h1 className="font-display font-bold tracking-wide leading-[0.94] text-[clamp(3.1rem,11vw,5.4rem)] select-none">
            <span className="block title-3d-zain">ZAIN</span>
            <span className="block title-3d-runner -mt-1">RUNNER</span>
          </h1>
          <p
            className="mt-3 px-4 py-1 rounded-full text-sm sm:text-base font-bold tracking-wide text-amber-100 border border-amber-300/30 shadow-md"
            style={{ backgroundColor: 'rgba(15, 23, 42, 0.78)' }}
          >
            Created By Zain
          </p>
        </div>
      </div>

      {/* Bottom Thumb-Zone CTA */}
      <div className="relative z-10 flex flex-col items-center gap-4 pb-3">
        <button
          type="button"
          onClick={onStart}
          className="animate-btn-glow min-h-[60px] w-full max-w-[290px] px-8 py-4 rounded-3xl bg-gradient-to-b from-amber-300 via-amber-400 to-orange-500 text-slate-950 font-display font-bold text-2xl tracking-wider flex items-center justify-center gap-3 border-2 border-amber-100 active:translate-y-1 transition-transform cursor-pointer whitespace-nowrap"
        >
          <Play className="w-7 h-7 fill-slate-950 shrink-0" />
          <span>START</span>
        </button>

        <p
          className="text-xs sm:text-sm font-medium text-slate-100 px-3.5 py-1.5 rounded-xl border border-white/10"
          style={{ backgroundColor: 'rgba(15, 23, 42, 0.75)' }}
        >
          Swipe or Arrow Keys · Left / Right · Up Jump · Down Slide
        </p>
      </div>
    </div>
  );
};
