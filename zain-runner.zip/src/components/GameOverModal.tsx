import React from 'react';
import { Coins, Home, RotateCcw, Route, Trophy } from 'lucide-react';
import { GameHUDState } from '../game/types';

interface GameOverModalProps {
  hud: GameHUDState;
  onRestart: () => void;
  onMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  hud,
  onRestart,
  onMenu,
}) => {
  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-5"
      style={{ backgroundColor: 'rgba(2, 6, 23, 0.8)' }}
    >
      <div
        className="w-full max-w-sm rounded-3xl border border-white/15 p-6 shadow-2xl flex flex-col gap-5 text-center"
        style={{ backgroundColor: '#0f172a' }}
      >
        <div>
          {hud.isNewBest && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold mb-2">
              <Trophy className="w-3.5 h-3.5" />
              <span>New Best Score</span>
            </div>
          )}
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-wide">
            RUN OVER
          </h2>
          <p className="mt-1 text-xs font-medium text-slate-400">
            Zain Runner · Created By Zain
          </p>
        </div>

        {/* Score Breakdown */}
        <div className="rounded-2xl bg-slate-800/90 border border-slate-700 p-4 flex flex-col gap-3">
          <div className="flex flex-col items-center pb-3 border-b border-slate-700">
            <span className="text-xs font-semibold text-slate-400">Final Score</span>
            <span className="font-mono-num text-4xl font-bold text-amber-300 mt-0.5">
              {hud.score.toLocaleString()}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center pt-1">
            <div className="flex flex-col items-center">
              <Trophy className="w-4 h-4 text-amber-400 mb-1" />
              <span className="text-[11px] text-slate-400">Best</span>
              <span className="font-mono-num text-sm font-bold text-white">
                {hud.bestScore.toLocaleString()}
              </span>
            </div>

            <div className="flex flex-col items-center">
              <Coins className="w-4 h-4 text-yellow-400 mb-1" />
              <span className="text-[11px] text-slate-400">Coins</span>
              <span className="font-mono-num text-sm font-bold text-white">
                {hud.coins.toLocaleString()}
              </span>
            </div>

            <div className="flex flex-col items-center">
              <Route className="w-4 h-4 text-sky-400 mb-1" />
              <span className="text-[11px] text-slate-400">Distance</span>
              <span className="font-mono-num text-sm font-bold text-white">
                {hud.distance}m
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={onRestart}
            className="min-h-[54px] w-full rounded-2xl bg-gradient-to-b from-amber-300 via-amber-400 to-orange-500 text-slate-950 font-display font-bold text-xl tracking-wide flex items-center justify-center gap-2.5 shadow-lg active:scale-[0.98] transition-transform cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-5 h-5 shrink-0" />
            <span>Play Again</span>
          </button>

          <button
            type="button"
            onClick={onMenu}
            className="min-h-[48px] w-full rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform cursor-pointer whitespace-nowrap"
          >
            <Home className="w-4 h-4 shrink-0" />
            <span>Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
