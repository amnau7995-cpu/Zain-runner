import React from 'react';
import { Coins, Magnet, Pause, Volume2, VolumeX, Zap } from 'lucide-react';
import { GameHUDState } from '../game/types';

interface GameHUDProps {
  hud: GameHUDState;
  isMuted: boolean;
  onPause: () => void;
  onToggleMute: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  hud,
  isMuted,
  onPause,
  onToggleMute,
}) => {
  const { score, coins, speedMultiplier, activePowerups, distance } = hud;
  const magnetPct =
    activePowerups.magnetDuration > 0
      ? Math.min(100, (activePowerups.magnetRemaining / activePowerups.magnetDuration) * 100)
      : 0;
  const boostPct =
    activePowerups.boostDuration > 0
      ? Math.min(100, (activePowerups.boostRemaining / activePowerups.boostDuration) * 100)
      : 0;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between px-4 pt-safe pb-safe">
      {/* Top HUD Bar */}
      <div className="flex items-start justify-between gap-3">
        {/* Score & Coins Cluster */}
        <div
          className="flex flex-col gap-1 rounded-2xl px-4 py-2.5 border border-white/15 shadow-lg min-w-[148px]"
          style={{ backgroundColor: 'rgba(15, 23, 42, 0.84)' }}
        >
          <div className="flex items-baseline justify-between gap-3">
            <span className="font-mono-num text-2xl sm:text-3xl font-bold text-white leading-none">
              {score.toLocaleString()}
            </span>
            <span className="font-mono-num text-xs font-semibold text-sky-300">
              {speedMultiplier.toFixed(1)}x
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs font-semibold text-slate-300">
            <span className="flex items-center gap-1 text-amber-300 font-mono-num">
              <Coins className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              {coins.toLocaleString()}
            </span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span className="font-mono-num text-slate-300">{distance}m</span>
          </div>
        </div>

        {/* Action Controls: Sound & Pause */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="min-h-[46px] min-w-[46px] flex items-center justify-center rounded-2xl border border-white/15 text-white shadow-lg active:scale-95 transition-transform cursor-pointer"
            style={{ backgroundColor: 'rgba(15, 23, 42, 0.84)' }}
          >
            {isMuted ? (
              <VolumeX className="w-5 h-5 text-slate-300" />
            ) : (
              <Volume2 className="w-5 h-5 text-sky-400" />
            )}
          </button>

          <button
            type="button"
            onClick={onPause}
            aria-label="Pause game"
            className="min-h-[46px] min-w-[46px] flex items-center justify-center rounded-2xl border border-white/15 text-white shadow-lg active:scale-95 transition-transform cursor-pointer"
            style={{ backgroundColor: 'rgba(15, 23, 42, 0.84)' }}
          >
            <Pause className="w-5 h-5 text-white fill-white" />
          </button>
        </div>
      </div>

      {/* Bottom Active Powerups & Subtle Controls Reminder */}
      <div className="flex flex-col items-center gap-2 pb-2">
        {(activePowerups.magnetRemaining > 0 || activePowerups.boostRemaining > 0) && (
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            {activePowerups.magnetRemaining > 0 && (
              <div
                className="flex items-center gap-2.5 rounded-2xl px-3.5 py-2 border border-sky-400/40 shadow-lg min-w-[152px]"
                style={{ backgroundColor: 'rgba(15, 23, 42, 0.88)' }}
              >
                <Magnet className="w-4 h-4 text-sky-400 shrink-0" />
                <div className="flex-1">
                  <div className="flex justify-between text-[11px] font-bold text-sky-200 mb-1">
                    <span>Magnet</span>
                    <span className="font-mono-num">{activePowerups.magnetRemaining.toFixed(1)}s</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-slate-700 overflow-hidden">
                    <div
                      className="h-full bg-sky-400 rounded-full transition-[width] duration-75"
                      style={{ width: `${magnetPct}%` }}
                    />
                  </div>
                </div>
              </div>
            )}

            {activePowerups.boostRemaining > 0 && (
              <div
                className="flex items-center gap-2.5 rounded-2xl px-3.5 py-2 border border-amber-400/40 shadow-lg min-w-[152px]"
                style={{ backgroundColor: 'rgba(15, 23, 42, 0.88)' }}
              >
                <Zap className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
                <div className="flex-1">
                  <div className="flex justify-between text-[11px] font-bold text-amber-200 mb-1">
                    <span>Speed Boost</span>
                    <span className="font-mono-num">{activePowerups.boostRemaining.toFixed(1)}s</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-slate-700 overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-[width] duration-75"
                      style={{ width: `${boostPct}%` }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
