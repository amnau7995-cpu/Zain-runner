import { useCallback, useEffect, useRef, useState } from 'react';
import { GameHUD } from './components/GameHUD';
import { GameOverModal } from './components/GameOverModal';
import { MainMenu } from './components/MainMenu';
import { PauseModal } from './components/PauseModal';
import { soundEngine } from './game/audio';
import { RunnerEngine } from './game/RunnerEngine';
import { GameHUDState } from './game/types';

const INITIAL_HUD: GameHUDState = {
  phase: 'menu',
  score: 0,
  bestScore: 0,
  coins: 0,
  distance: 0,
  speedMultiplier: 1.0,
  isNewBest: false,
  activePowerups: {
    magnetRemaining: 0,
    magnetDuration: 8.5,
    boostRemaining: 0,
    boostDuration: 6.0,
  },
  webglLost: false,
};

const SWIPE_THRESHOLD_PX = 24;

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<RunnerEngine | null>(null);
  const [hud, setHud] = useState<GameHUDState>(INITIAL_HUD);
  const [isMuted, setIsMuted] = useState<boolean>(() => soundEngine.isMuted());

  // Touch/Pointer swipe tracking
  const swipeStateRef = useRef<{
    active: boolean;
    startX: number;
    startY: number;
    consumed: boolean;
  }>({
    active: false,
    startX: 0,
    startY: 0,
    consumed: false,
  });

  // Mount Three.js RunnerEngine once
  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    const engine = new RunnerEngine(container, {
      onStateChange: (nextState) => {
        setHud(nextState);
      },
    });
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Auto-pause when mobile app / tab loses visibility
  useEffect(() => {
    const onVisibilityChange = () => {
      if (document.hidden) {
        engineRef.current?.pauseGame();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => document.removeEventListener('visibilitychange', onVisibilityChange);
  }, []);

  // Keyboard controls (Desktop & Emulator)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const engine = engineRef.current;
      if (!engine) return;

      if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
        e.preventDefault();
        engine.moveLeft();
      } else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
        e.preventDefault();
        engine.moveRight();
      } else if (e.code === 'ArrowUp' || e.code === 'KeyW' || e.code === 'Space') {
        e.preventDefault();
        engine.jump();
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        engine.slide();
      } else if (e.code === 'Escape' || e.code === 'KeyP') {
        e.preventDefault();
        if (hud.phase === 'playing') engine.pauseGame();
        else if (hud.phase === 'paused') engine.resumeGame();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [hud.phase]);

  // Unified immediate swipe handlers (supports touch & mouse drag)
  const beginSwipe = useCallback((clientX: number, clientY: number) => {
    soundEngine.unlock();
    swipeStateRef.current = {
      active: true,
      startX: clientX,
      startY: clientY,
      consumed: false,
    };
  }, []);

  const moveSwipe = useCallback((clientX: number, clientY: number) => {
    const state = swipeStateRef.current;
    if (!state.active || state.consumed) return;
    const engine = engineRef.current;
    if (!engine) return;

    const dx = clientX - state.startX;
    const dy = clientY - state.startY;
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);

    if (absX < SWIPE_THRESHOLD_PX && absY < SWIPE_THRESHOLD_PX) return;

    state.consumed = true;
    if (absX > absY) {
      if (dx < 0) engine.moveLeft();
      else engine.moveRight();
    } else {
      if (dy < 0) engine.jump();
      else engine.slide();
    }
  }, []);

  const endSwipe = useCallback(() => {
    swipeStateRef.current.active = false;
  }, []);

  const handleStart = useCallback(() => {
    engineRef.current?.startGame();
  }, []);

  const handleRestart = useCallback(() => {
    engineRef.current?.restartGame();
  }, []);

  const handlePause = useCallback(() => {
    engineRef.current?.pauseGame();
  }, []);

  const handleResume = useCallback(() => {
    engineRef.current?.resumeGame();
  }, []);

  const handleMenu = useCallback(() => {
    engineRef.current?.returnToMenu();
  }, []);

  const handleToggleMute = useCallback(() => {
    soundEngine.unlock();
    const muted = soundEngine.toggleMute();
    setIsMuted(muted);
  }, []);

  return (
    <div
      className="relative w-full h-full overflow-hidden bg-slate-950"
      onTouchStart={(e) => {
        if (e.touches.length > 0) {
          beginSwipe(e.touches[0].clientX, e.touches[0].clientY);
        }
      }}
      onTouchMove={(e) => {
        if (e.touches.length > 0) {
          moveSwipe(e.touches[0].clientX, e.touches[0].clientY);
        }
      }}
      onTouchEnd={endSwipe}
      onTouchCancel={endSwipe}
      onPointerDown={(e) => {
        if (e.pointerType === 'mouse') {
          beginSwipe(e.clientX, e.clientY);
        }
      }}
      onPointerMove={(e) => {
        if (e.pointerType === 'mouse') {
          moveSwipe(e.clientX, e.clientY);
        }
      }}
      onPointerUp={endSwipe}
    >
      {/* Isolated WebGL Canvas Mount */}
      <div ref={canvasMountRef} className="fixed inset-0 z-0 w-full h-full" />

      {/* Main Menu & Transition Fade */}
      {(hud.phase === 'menu' || hud.phase === 'transitioning') && (
        <MainMenu
          bestScore={hud.bestScore}
          isMuted={isMuted}
          isTransitioning={hud.phase === 'transitioning'}
          onStart={handleStart}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Active Gameplay HUD */}
      {hud.phase === 'playing' && (
        <GameHUD
          hud={hud}
          isMuted={isMuted}
          onPause={handlePause}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Pause Overlay */}
      {hud.phase === 'paused' && (
        <PauseModal
          score={hud.score}
          coins={hud.coins}
          isMuted={isMuted}
          onResume={handleResume}
          onRestart={handleRestart}
          onMenu={handleMenu}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Game Over Overlay */}
      {hud.phase === 'gameover' && (
        <GameOverModal
          hud={hud}
          onRestart={handleRestart}
          onMenu={handleMenu}
        />
      )}

      {/* WebGL Context Lost Fallback */}
      {hud.webglLost && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-6 text-center"
          style={{ backgroundColor: 'rgba(15, 23, 42, 0.94)' }}
        >
          <div className="max-w-xs rounded-3xl border border-white/15 p-6 bg-slate-900">
            <h2 className="font-display text-2xl font-bold text-white">Graphics Paused</h2>
            <p className="mt-2 text-sm text-slate-300">
              Your device temporarily suspended 3D graphics. Restoring scene...
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
