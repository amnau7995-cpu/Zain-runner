import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { soundEngine } from './audio';
import {
  AssetFactory,
  CharacterRig,
  createCharacterRig,
  LANE_POSITIONS,
  TRACK_SEGMENT_LENGTH,
  TRAIN_HEIGHT,
} from './models';
import { createProceduralTextures } from './textures';
import { GameHUDState, GamePhase, ObstacleKind, PowerupKind, RunnerEngineCallbacks } from './types';

const BEST_SCORE_KEY = 'zain_runner_best_score';
const TRACK_COUNT = 8;
const BASE_SPEED = 17.5;
const MAX_SPEED = 38.0;
const MAGNET_DURATION = 8.5;
const BOOST_DURATION = 6.0;
const PARTICLE_POOL_SIZE = 96;

// Reusable module-level math helpers (Zero GC in tick)
const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();

interface PooledObstacle {
  active: boolean;
  kind: ObstacleKind;
  lane: number;
  x: number;
  z: number;
  extraSpeed: number;
  smashed: boolean;
  smashVx: number;
  smashVy: number;
  smashRot: number;
  mesh: THREE.Group;
}

interface PooledCoin {
  active: boolean;
  lane: number;
  x: number;
  y: number;
  z: number;
  baseY: number;
  attracted: boolean;
  mesh: THREE.Group;
}

interface PooledPowerup {
  active: boolean;
  kind: PowerupKind;
  lane: number;
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
}

interface Particle {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
  colorHex: number;
}

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return false;
  }
}

export class RunnerEngine {
  private container: HTMLElement;
  private callbacks: RunnerEngineCallbacks;
  private isSoftwareGl: boolean;

  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private envRenderTarget: THREE.WebGLRenderTarget;
  private dirLight: THREE.DirectionalLight;
  private assetFactory: AssetFactory;
  private character: CharacterRig;
  private playerShadow: THREE.Mesh;

  // World & Pools
  private trackSegments: { group: THREE.Group; z: number }[] = [];
  private obstaclePools: Record<ObstacleKind, PooledObstacle[]> = {
    low_barrier: [],
    high_barrier: [],
    tall_barrier: [],
    train_static: [],
    train_ramp: [],
    train_moving: [],
  };
  private coinPool: PooledCoin[] = [];
  private powerupPools: Record<PowerupKind, PooledPowerup[]> = {
    magnet: [],
    boost: [],
  };

  // Instanced 3D particles
  private particleMesh: THREE.InstancedMesh;
  private particles: Particle[] = [];

  // Game State
  private phase: GamePhase = 'menu';
  private transitionProgress = 0;
  private elapsed = 0;
  private speed = BASE_SPEED;
  private distance = 0;
  private coins = 0;
  private score = 0;
  private bestScore = 0;
  private isNewBest = false;
  private webglLost = false;

  // Player Physics
  private targetLane = 1; // 0 = left, 1 = center, 2 = right
  private playerX = 0;
  private prevPlayerX = 0;
  private playerY = 0;
  private velocityY = 0;
  private isGrounded = true;
  private slideTimer = 0;
  private queuedSlide = false;
  private runCycle = 0;
  private crashTimer = 0;
  private cameraShake = 0;
  private landingTimer = 0;
  private blinkTimer = 0;
  private nextBlinkDelay = 2.6;
  private wasAirborne = false;

  // Powerups
  private magnetTimer = 0;
  private boostTimer = 0;

  // Spawning
  private spawnZ = -50;
  private waveIndex = 0;

  // Loop management
  private frameId = 0;
  private lastTimestamp = 0;
  private disposed = false;
  private hudSyncAccum = 0;
  private ambientAccum = 0;

  // Event handler refs
  private handleResize: () => void;
  private handleContextLost: (e: Event) => void;
  private handleContextRestored: () => void;

  constructor(container: HTMLElement, callbacks: RunnerEngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.isSoftwareGl = detectSoftwareWebGL();

    try {
      const saved = localStorage.getItem(BEST_SCORE_KEY);
      if (saved) this.bestScore = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      this.bestScore = 0;
    }

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Scene + vibrant sunny-sky atmosphere
    this.scene = new THREE.Scene();
    const skyColor = new THREE.Color(0x7dd3fc);
    this.scene.background = skyColor;
    this.scene.fog = new THREE.Fog(0xbae6fd, 68, 175);

    // Camera
    this.camera = new THREE.PerspectiveCamera(62, width / height, 0.1, 220);
    this.camera.position.set(2.4, 2.3, 4.6);
    this.camera.lookAt(0, 1.35, -0.5);

    // Mandatory studio environment reflection map
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.envRenderTarget = pmrem.fromScene(roomEnv, 0.04);
    this.scene.environment = this.envRenderTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    // Warm/cool 3-point outdoor lighting rig
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x334155, 0.85);
    this.scene.add(hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xfffbeb, 1.75);
    this.dirLight.position.set(14, 24, 16);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.width = 1024;
    this.dirLight.shadow.mapSize.height = 1024;
    const d = 18;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.dirLight.shadow.camera.near = 2;
    this.dirLight.shadow.camera.far = 65;
    this.dirLight.shadow.bias = -0.0005;
    this.dirLight.shadow.normalBias = 0.02;
    this.scene.add(this.dirLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.55);
    rimLight.position.set(-12, 10, -16);
    this.scene.add(rimLight);

    // Extended horizon ground plane so world never ends in an empty void
    const groundGeo = new THREE.PlaneGeometry(420, 420);
    groundGeo.rotateX(-Math.PI / 2);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f766e,
      roughness: 0.95,
      metalness: 0.02,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.position.set(0, -0.08, -70);
    ground.receiveShadow = true;
    this.scene.add(ground);

    // Build procedural textures & asset pools
    const textures = createProceduralTextures(this.renderer.capabilities.getMaxAnisotropy());
    this.assetFactory = new AssetFactory(textures);

    // Character & grounded contact shadow
    this.character = createCharacterRig();
    this.scene.add(this.character.group);
    this.playerShadow = this.assetFactory.createContactShadow(1.1);
    this.scene.add(this.playerShadow);

    // Track segments pool
    for (let i = 0; i < TRACK_COUNT; i++) {
      const seg = this.assetFactory.createTrackSegment(i);
      const z = 15 - i * TRACK_SEGMENT_LENGTH;
      seg.position.z = z;
      this.scene.add(seg);
      this.trackSegments.push({ group: seg, z });
    }

    // Obstacle pools
    const poolCounts: Record<ObstacleKind, number> = {
      low_barrier: 8,
      high_barrier: 8,
      tall_barrier: 8,
      train_static: 6,
      train_ramp: 4,
      train_moving: 4,
    };
    (Object.keys(poolCounts) as ObstacleKind[]).forEach((kind) => {
      for (let i = 0; i < poolCounts[kind]; i++) {
        const mesh = this.assetFactory.createObstacleMesh(kind);
        mesh.visible = false;
        this.scene.add(mesh);
        this.obstaclePools[kind].push({
          active: false,
          kind,
          lane: 1,
          x: 0,
          z: 0,
          extraSpeed: 0,
          smashed: false,
          smashVx: 0,
          smashVy: 0,
          smashRot: 0,
          mesh,
        });
      }
    });

    // Coin pool (80 coins)
    for (let i = 0; i < 80; i++) {
      const mesh = this.assetFactory.createCoinMesh();
      mesh.visible = false;
      this.scene.add(mesh);
      this.coinPool.push({
        active: false,
        lane: 1,
        x: 0,
        y: 1,
        z: 0,
        baseY: 1,
        attracted: false,
        mesh,
      });
    }

    // Powerup pools
    (['magnet', 'boost'] as PowerupKind[]).forEach((kind) => {
      for (let i = 0; i < 3; i++) {
        const mesh = this.assetFactory.createPowerupMesh(kind);
        mesh.visible = false;
        this.scene.add(mesh);
        this.powerupPools[kind].push({
          active: false,
          kind,
          lane: 1,
          x: 0,
          y: 1.2,
          z: 0,
          mesh,
        });
      }
    });

    // Pooled InstancedMesh Particles
    const pGeo = new THREE.BoxGeometry(1, 1, 1);
    const pMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.particleMesh = new THREE.InstancedMesh(pGeo, pMat, PARTICLE_POOL_SIZE);
    this.particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.particleMesh.frustumCulled = false;
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -100,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 1,
        size: 0.1,
        colorHex: 0xffffff,
      });
      _pos.set(0, -100, 0);
      _scale.setScalar(0.001);
      _mat4.compose(_pos, _quat, _scale);
      this.particleMesh.setMatrixAt(i, _mat4);
      this.particleMesh.setColorAt(i, _color.setHex(0xffffff));
    }
    this.particleMesh.instanceMatrix.needsUpdate = true;
    if (this.particleMesh.instanceColor) this.particleMesh.instanceColor.needsUpdate = true;
    this.scene.add(this.particleMesh);

    // Pre-warm shaders on GPU
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    // Bind resize & context loss handlers
    this.handleResize = () => {
      if (this.disposed) return;
      const w = this.container.clientWidth || window.innerWidth;
      const h = this.container.clientHeight || window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
      this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    };
    window.addEventListener('resize', this.handleResize);

    this.handleContextLost = (e: Event) => {
      e.preventDefault();
      this.webglLost = true;
      if (this.phase === 'playing') {
        this.phase = 'paused';
      }
      this.emitHUDState();
    };
    this.handleContextRestored = () => {
      this.webglLost = false;
      this.emitHUDState();
    };
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);

    this.emitHUDState();
    this.lastTimestamp = performance.now();
    this.scheduleNextFrame();
  }

  // Public Controls -----------------------------------------------------------

  public startGame(): void {
    soundEngine.unlock();
    soundEngine.playStart();
    this.resetWorldEntities();
    this.phase = 'transitioning';
    this.transitionProgress = 0;
    this.emitHUDState();
  }

  public restartGame(): void {
    soundEngine.unlock();
    soundEngine.playStart();
    this.resetWorldEntities();
    this.phase = 'playing';
    this.transitionProgress = 1;
    this.seedInitialWaves();
    this.emitHUDState();
  }

  public pauseGame(): void {
    if (this.phase === 'playing') {
      this.phase = 'paused';
      this.emitHUDState();
    }
  }

  public resumeGame(): void {
    if (this.phase === 'paused') {
      this.lastTimestamp = performance.now();
      this.phase = 'playing';
      this.emitHUDState();
    }
  }

  public returnToMenu(): void {
    this.resetWorldEntities();
    this.phase = 'menu';
    this.transitionProgress = 0;
    this.emitHUDState();
  }

  public moveLeft(): void {
    if (this.phase !== 'playing') return;
    if (this.targetLane > 0) {
      this.targetLane -= 1;
      soundEngine.playLane();
    }
  }

  public moveRight(): void {
    if (this.phase !== 'playing') return;
    if (this.targetLane < 2) {
      this.targetLane += 1;
      soundEngine.playLane();
    }
  }

  public jump(): void {
    if (this.phase !== 'playing') return;
    if (this.isGrounded) {
      this.velocityY = 14.6;
      this.isGrounded = false;
      this.slideTimer = 0;
      this.queuedSlide = false;
      soundEngine.playJump();
      this.spawnBurst(this.playerX, this.playerY + 0.1, 0.1, 8, 0xe2e8f0, 0.12);
    }
  }

  public slide(): void {
    if (this.phase !== 'playing') return;
    if (!this.isGrounded) {
      // Fast fall mid-air and queue slide on touchdown
      this.velocityY = Math.min(this.velocityY, -24);
      this.queuedSlide = true;
      soundEngine.playSlide();
    } else if (this.slideTimer <= 0.1) {
      this.slideTimer = 0.68;
      soundEngine.playSlide();
      this.spawnBurst(this.playerX, this.playerY + 0.12, 0.2, 6, 0xfbbf24, 0.1);
    }
  }

  // World Reset & Wave Spawner ------------------------------------------------

  private resetWorldEntities(): void {
    this.speed = BASE_SPEED;
    this.distance = 0;
    this.coins = 0;
    this.score = 0;
    this.isNewBest = false;

    this.targetLane = 1;
    this.playerX = 0;
    this.prevPlayerX = 0;
    this.playerY = 0;
    this.velocityY = 0;
    this.isGrounded = true;
    this.slideTimer = 0;
    this.queuedSlide = false;
    this.crashTimer = 0;
    this.cameraShake = 0;
    this.landingTimer = 0;
    this.blinkTimer = 0;
    this.wasAirborne = false;
    this.magnetTimer = 0;
    this.boostTimer = 0;

    this.character.group.position.set(0, 0, 0);
    this.character.group.rotation.set(0, 0, 0);
    this.character.group.scale.set(1, 1, 1);
    this.character.boostAura.visible = false;
    this.character.magnetAura.visible = false;

    // Reset track segment positions
    for (let i = 0; i < this.trackSegments.length; i++) {
      const z = 15 - i * TRACK_SEGMENT_LENGTH;
      this.trackSegments[i].z = z;
      this.trackSegments[i].group.position.z = z;
    }

    // Deactivate obstacles, coins, powerups
    (Object.keys(this.obstaclePools) as ObstacleKind[]).forEach((k) => {
      this.obstaclePools[k].forEach((o) => {
        o.active = false;
        o.smashed = false;
        o.mesh.visible = false;
        o.mesh.rotation.set(0, 0, 0);
      });
    });
    this.coinPool.forEach((c) => {
      c.active = false;
      c.attracted = false;
      c.mesh.visible = false;
    });
    (['magnet', 'boost'] as PowerupKind[]).forEach((k) => {
      this.powerupPools[k].forEach((p) => {
        p.active = false;
        p.mesh.visible = false;
      });
    });

    this.spawnZ = -48;
    this.waveIndex = 0;
  }

  private seedInitialWaves(): void {
    while (this.spawnZ > -155) {
      this.spawnNextWave();
    }
  }

  private acquireObstacle(kind: ObstacleKind, lane: number, z: number): PooledObstacle | null {
    const pool = this.obstaclePools[kind];
    for (let i = 0; i < pool.length; i++) {
      const item = pool[i];
      if (!item.active) {
        item.active = true;
        item.lane = lane;
        item.x = LANE_POSITIONS[lane];
        item.z = z;
        item.extraSpeed = kind === 'train_moving' ? 11.5 : 0;
        item.smashed = false;
        item.smashVx = 0;
        item.smashVy = 0;
        item.smashRot = 0;
        item.mesh.position.set(item.x, 0, z);
        item.mesh.rotation.set(0, 0, 0);
        item.mesh.visible = true;
        return item;
      }
    }
    return null;
  }

  private spawnCoin(lane: number, y: number, z: number): void {
    for (let i = 0; i < this.coinPool.length; i++) {
      const c = this.coinPool[i];
      if (!c.active) {
        c.active = true;
        c.lane = lane;
        c.x = LANE_POSITIONS[lane];
        c.y = y;
        c.baseY = y;
        c.z = z;
        c.attracted = false;
        c.mesh.position.set(c.x, y, z);
        c.mesh.visible = true;
        return;
      }
    }
  }

  private spawnCoinLine(lane: number, startZ: number, count: number, spacing: number, y = 0.85): void {
    for (let i = 0; i < count; i++) {
      this.spawnCoin(lane, y, startZ - i * spacing);
    }
  }

  private spawnCoinArc(lane: number, centerZ: number, peakY = 2.25): void {
    const offsets = [-3.6, -1.8, 0, 1.8, 3.6];
    for (let i = 0; i < offsets.length; i++) {
      const t = (i - 2) / 2;
      const y = 0.85 + (1 - t * t) * (peakY - 0.85);
      this.spawnCoin(lane, y, centerZ + offsets[i]);
    }
  }

  private spawnPowerup(kind: PowerupKind, lane: number, y: number, z: number): void {
    const pool = this.powerupPools[kind];
    for (let i = 0; i < pool.length; i++) {
      const p = pool[i];
      if (!p.active) {
        p.active = true;
        p.lane = lane;
        p.x = LANE_POSITIONS[lane];
        p.y = y;
        p.z = z;
        p.mesh.position.set(p.x, y, z);
        p.mesh.visible = true;
        return;
      }
    }
  }

  private spawnNextWave(): void {
    this.waveIndex += 1;
    const z = this.spawnZ;
    const pattern = (this.waveIndex + Math.floor(Math.random() * 5)) % 6;

    // Choose lanes deterministically shuffled
    const lanes = [0, 1, 2];
    for (let i = 2; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = lanes[i];
      lanes[i] = lanes[j];
      lanes[j] = tmp;
    }

    if (pattern === 0) {
      // Jumpable low barrier + high slide barrier + open coin lane
      this.acquireObstacle('low_barrier', lanes[0], z);
      this.spawnCoinArc(lanes[0], z, 2.35);
      this.acquireObstacle('high_barrier', lanes[1], z - 4);
      this.spawnCoinLine(lanes[1], z - 2, 3, 2.2, 0.65);
      this.spawnCoinLine(lanes[2], z, 5, 2.4, 0.9);
      this.spawnZ -= 26;
    } else if (pattern === 1) {
      // Ramp train you can run onto + static train + low barrier
      this.acquireObstacle('train_ramp', lanes[0], z - 9);
      // Coins leading up the ramp and across the train roof!
      this.spawnCoin(lanes[0], 1.1, z + 0.5);
      this.spawnCoin(lanes[0], 2.2, z - 1.5);
      this.spawnCoinLine(lanes[0], z - 4, 5, 2.3, TRAIN_HEIGHT + 0.85);

      this.acquireObstacle('train_static', lanes[1], z - 9);
      this.acquireObstacle('low_barrier', lanes[2], z - 4);
      this.spawnCoinLine(lanes[2], z - 8, 4, 2.4, 0.9);
      this.spawnZ -= 36;
    } else if (pattern === 2) {
      // Oncoming express train in one lane, slide gantry in another, safe third lane
      this.acquireObstacle('train_moving', lanes[0], z - 16);
      this.acquireObstacle('high_barrier', lanes[1], z - 2);
      this.spawnCoinLine(lanes[2], z + 2, 6, 2.4, 0.9);
      this.spawnZ -= 34;
    } else if (pattern === 3) {
      // Rhythmic blockade slalom
      this.acquireObstacle('tall_barrier', lanes[0], z);
      this.acquireObstacle('tall_barrier', lanes[1], z);
      this.spawnCoinLine(lanes[2], z + 2, 4, 2.2, 0.9);

      this.acquireObstacle('low_barrier', lanes[2], z - 15);
      this.spawnCoinArc(lanes[2], z - 15, 2.35);
      this.spawnZ -= 34;
    } else if (pattern === 4) {
      // Twin static trains with center corridor
      this.acquireObstacle('train_static', lanes[0], z - 8);
      this.acquireObstacle('train_static', lanes[1], z - 8);
      this.acquireObstacle('high_barrier', lanes[2], z - 6);
      this.spawnCoinLine(lanes[2], z - 2, 5, 2.4, 0.65);
      this.spawnZ -= 34;
    } else {
      // Diagonal coin switch + double low barriers
      this.acquireObstacle('low_barrier', lanes[0], z);
      this.acquireObstacle('low_barrier', lanes[1], z);
      for (let i = 0; i < 6; i++) {
        const l = i < 2 ? lanes[2] : i < 4 ? 1 : lanes[0];
        this.spawnCoin(l, 0.9, z + 2 - i * 2.5);
      }
      this.spawnZ -= 27;
    }

    // Periodic Magnet or Speed Boost powerup
    if (this.waveIndex % 4 === 2) {
      const pKind: PowerupKind = this.waveIndex % 8 === 2 ? 'magnet' : 'boost';
      this.spawnPowerup(pKind, lanes[2], 1.15, z - 11);
    }
  }

  // Particle System (Zero GC) -------------------------------------------------

  private spawnBurst(
    x: number,
    y: number,
    z: number,
    count: number,
    colorHex: number,
    size = 0.14
  ): void {
    let spawned = 0;
    for (let i = 0; i < PARTICLE_POOL_SIZE && spawned < count; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.x = x + (Math.random() - 0.5) * 0.35;
        p.y = y + (Math.random() - 0.5) * 0.25;
        p.z = z + (Math.random() - 0.5) * 0.35;
        p.vx = (Math.random() - 0.5) * 5.2;
        p.vy = 1.8 + Math.random() * 4.2;
        p.vz = (Math.random() - 0.5) * 4.5;
        p.life = 0;
        p.maxLife = 0.35 + Math.random() * 0.3;
        p.size = size * (0.7 + Math.random() * 0.6);
        p.colorHex = colorHex;
        spawned++;
      }
    }
  }

  private spawnAmbientMote(): void {
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.x = (Math.random() - 0.5) * 11;
        p.y = 0.6 + Math.random() * 3.8;
        p.z = -18 - Math.random() * 24;
        p.vx = (Math.random() - 0.5) * 0.6;
        p.vy = 0.5 + Math.random() * 0.9;
        p.vz = 4 + Math.random() * 4;
        p.life = 0;
        p.maxLife = 1.6 + Math.random() * 1.1;
        p.size = 0.1 + Math.random() * 0.08;
        p.colorHex = Math.random() > 0.45 ? 0xfef08a : 0x7dd3fc;
        return;
      }
    }
  }

  private updateParticles(dt: number): void {
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      const p = this.particles[i];
      if (p.active) {
        p.life += dt;
        if (p.life >= p.maxLife) {
          p.active = false;
          _pos.set(0, -100, 0);
          _scale.setScalar(0.001);
          _mat4.compose(_pos, _quat, _scale);
          this.particleMesh.setMatrixAt(i, _mat4);
        } else {
          p.vy -= 9.5 * dt;
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.z += p.vz * dt;
          const fade = 1 - p.life / p.maxLife;
          _pos.set(p.x, p.y, p.z);
          _scale.setScalar(p.size * fade);
          _mat4.compose(_pos, _quat, _scale);
          this.particleMesh.setMatrixAt(i, _mat4);
          this.particleMesh.setColorAt(i, _color.setHex(p.colorHex));
        }
      }
    }
    this.particleMesh.instanceMatrix.needsUpdate = true;
    if (this.particleMesh.instanceColor) this.particleMesh.instanceColor.needsUpdate = true;
  }

  // Frame Loop & Simulation ---------------------------------------------------

  private scheduleNextFrame(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = requestAnimationFrame(() => this.tick());
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || !gl.fenceSync) {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick(): void {
    if (this.disposed) return;
    const now = performance.now();
    const rawDt = (now - this.lastTimestamp) / 1000;
    this.lastTimestamp = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    this.elapsed += dt;

    if (this.phase === 'menu') {
      this.updateMenuScene(dt);
    } else if (this.phase === 'transitioning') {
      this.updateTransition(dt);
    } else if (this.phase === 'playing') {
      this.updateGameplay(dt);
    } else if (this.phase === 'gameover') {
      this.updateGameOver(dt);
    }
    // Note: when paused, scene stays frozen for crisp pause screen!

    this.renderer.render(this.scene, this.camera);
    this.scheduleNextFrame();
  }

  private updateMenuScene(dt: number): void {
    // Gentle track scroll behind hero for lively 3D menu backdrop
    const menuScrollSpeed = 7.5;
    this.scrollTrack(menuScrollSpeed * dt);

    // Ambient floating golden/cyan motes
    this.ambientAccum += dt;
    if (this.ambientAccum > 0.14) {
      this.ambientAccum = 0;
      this.spawnAmbientMote();
    }
    this.updateParticles(dt);

    // Hero idle / stylish jog pose facing slightly toward camera
    this.character.group.position.set(0, 0, 0);
    this.character.group.rotation.set(0, Math.PI * 0.85, 0);
    this.animateCharacterJog(dt * 0.65, 0);
    this.playerShadow.position.set(0, 0.03, 0);
    this.playerShadow.scale.setScalar(1.1);

    // Smooth cinematic orbiting showcase camera
    const camX = Math.sin(this.elapsed * 0.55) * 1.15 + 1.85;
    const camY = 2.05 + Math.sin(this.elapsed * 0.8) * 0.12;
    this.camera.position.set(camX, camY, 4.4);
    this.camera.lookAt(0, 1.32, 0);
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, 58, 6, dt);
    this.camera.updateProjectionMatrix();
  }

  private updateTransition(dt: number): void {
    this.transitionProgress = Math.min(1, this.transitionProgress + dt * 1.9);
    const t = 1 - Math.pow(1 - this.transitionProgress, 3);

    this.scrollTrack(BASE_SPEED * 0.55 * dt);
    this.updateParticles(dt);

    // Character turns cleanly around to face -Z track
    this.character.group.rotation.y = THREE.MathUtils.lerp(Math.PI * 0.85, 0, t);
    this.animateCharacterJog(dt, 0);

    // Camera sweeps smoothly behind character into third-person chase angle
    this.camera.position.x = THREE.MathUtils.lerp(1.85, 0, t);
    this.camera.position.y = THREE.MathUtils.lerp(2.05, 4.1, t);
    this.camera.position.z = THREE.MathUtils.lerp(4.4, 6.4, t);

    const lookZ = THREE.MathUtils.lerp(0, -8.5, t);
    const lookY = THREE.MathUtils.lerp(1.32, 1.45, t);
    this.camera.lookAt(0, lookY, lookZ);
    this.camera.fov = THREE.MathUtils.lerp(58, 63, t);
    this.camera.updateProjectionMatrix();

    if (this.transitionProgress >= 1) {
      this.phase = 'playing';
      this.character.group.rotation.set(0, 0, 0);
      this.seedInitialWaves();
      this.emitHUDState();
    }
  }

  private updateGameplay(dt: number): void {
    // Powerup timers
    if (this.magnetTimer > 0) {
      this.magnetTimer = Math.max(0, this.magnetTimer - dt);
      this.character.magnetAura.visible = this.magnetTimer > 0;
      this.character.magnetAura.rotation.z += dt * 4.5;
    } else {
      this.character.magnetAura.visible = false;
    }

    const boostActive = this.boostTimer > 0;
    if (boostActive) {
      this.boostTimer = Math.max(0, this.boostTimer - dt);
      this.character.boostAura.visible = this.boostTimer > 0;
      this.character.boostAura.rotation.y += dt * 7;
    } else {
      this.character.boostAura.visible = false;
    }

    // Progressive speed ramp
    const naturalSpeed = Math.min(MAX_SPEED, BASE_SPEED + this.distance * 0.011);
    const targetSpeed = boostActive ? Math.min(MAX_SPEED + 9, naturalSpeed * 1.45) : naturalSpeed;
    this.speed = THREE.MathUtils.damp(this.speed, targetSpeed, 6, dt);

    const forwardStep = this.speed * dt;
    this.distance += forwardStep;
    this.score = Math.floor(this.distance * (boostActive ? 2 : 1) + this.coins * 10);
    if (this.score > this.bestScore) {
      this.bestScore = this.score;
      this.isNewBest = true;
    }

    // Scroll endless track
    this.scrollTrack(forwardStep);

    // Spawn upcoming waves as cursor scrolls toward player
    this.spawnZ += forwardStep;
    while (this.spawnZ > -155) {
      this.spawnNextWave();
    }

    // Horizontal lane damping
    this.prevPlayerX = this.playerX;
    const goalX = LANE_POSITIONS[this.targetLane];
    this.playerX = THREE.MathUtils.damp(this.playerX, goalX, 17, dt);
    const lateralVel = (this.playerX - this.prevPlayerX) / dt;

    // Determine ground height beneath player (floor or train roof / ramp!)
    const supportY = this.getGroundSupportHeight(this.playerX, this.playerY);

    // Vertical jump & gravity
    const prevGrounded = this.isGrounded;
    if (!this.isGrounded || this.playerY > supportY + 0.02) {
      this.velocityY += -39 * dt;
      this.playerY += this.velocityY * dt;
      const newSupport = this.getGroundSupportHeight(this.playerX, this.playerY);
      if (this.playerY <= newSupport) {
        this.playerY = newSupport;
        this.velocityY = 0;
        this.isGrounded = true;
        if (this.queuedSlide) {
          this.queuedSlide = false;
          this.slideTimer = 0.65;
        }
      } else {
        this.isGrounded = false;
      }
    } else {
      this.playerY = supportY;
      this.velocityY = 0;
      this.isGrounded = true;
    }

    // Trigger funny squash-and-stretch + goofy cartoon expression on jump landing
    if (!prevGrounded && this.isGrounded && this.wasAirborne) {
      this.landingTimer = 0.48;
      this.character.group.scale.set(1.24, 0.76, 1.24);
      this.spawnBurst(this.playerX, this.playerY + 0.08, 0.1, 6, 0xe2e8f0, 0.1);
    }
    this.wasAirborne = !this.isGrounded;

    if (this.landingTimer > 0) {
      this.landingTimer = Math.max(0, this.landingTimer - dt);
    }

    // Recover squash-and-stretch smoothly back to 1
    this.character.group.scale.x = THREE.MathUtils.damp(this.character.group.scale.x, 1, 13, dt);
    this.character.group.scale.y = THREE.MathUtils.damp(this.character.group.scale.y, 1, 13, dt);
    this.character.group.scale.z = THREE.MathUtils.damp(this.character.group.scale.z, 1, 13, dt);

    // Slide countdown
    if (this.slideTimer > 0) {
      this.slideTimer = Math.max(0, this.slideTimer - dt);
    }

    // Update character transform & pose
    this.character.group.position.set(this.playerX, this.playerY, 0);
    const bankAngle = THREE.MathUtils.clamp(-lateralVel * 0.032, -0.38, 0.38);
    this.character.group.rotation.z = THREE.MathUtils.damp(
      this.character.group.rotation.z,
      bankAngle,
      14,
      dt
    );

    if (this.slideTimer > 0) {
      this.animateCharacterSlide(dt);
    } else if (!this.isGrounded) {
      this.animateCharacterJump(dt);
    } else {
      this.animateCharacterJog(dt, lateralVel);
    }

    // Grounded contact shadow follows support height
    this.playerShadow.position.set(this.playerX, supportY + 0.03, 0);
    const airGap = Math.max(0, this.playerY - supportY);
    this.playerShadow.scale.setScalar(Math.max(0.45, 1.15 - airGap * 0.18));

    // Update obstacles & check collisions
    this.updateObstacles(dt, forwardStep, boostActive);

    // Update coins & magnet pull
    this.updateCoins(dt, forwardStep);

    // Update powerups
    this.updatePowerups(dt, forwardStep);

    // Ambient speed dust/motes
    this.ambientAccum += dt;
    if (this.ambientAccum > (boostActive ? 0.04 : 0.12)) {
      this.ambientAccum = 0;
      this.spawnAmbientMote();
      if (boostActive && this.isGrounded) {
        this.spawnBurst(this.playerX, this.playerY + 0.25, 0.4, 2, 0xfbbf24, 0.11);
      }
    }
    this.updateParticles(dt);

    // Dynamic Chase Camera + FOV widening
    const targetCamX = this.playerX * 0.62;
    const targetCamY = 4.05 + this.playerY * 0.72;
    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamX, 10, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamY, 10, dt);
    this.camera.position.z = 6.4;

    if (this.cameraShake > 0) {
      this.cameraShake = Math.max(0, this.cameraShake - dt * 3.5);
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShake * 0.35;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShake * 0.35;
    }

    this.camera.lookAt(this.playerX * 0.48, 1.4 + this.playerY * 0.65, -8.5);
    const targetFov = 62 + ((this.speed - BASE_SPEED) / (MAX_SPEED - BASE_SPEED)) * 11 + (boostActive ? 5 : 0);
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 6, dt);
    this.camera.updateProjectionMatrix();

    // Throttled React HUD sync (~20Hz) so React never bottlenecks 60 FPS WebGL
    this.hudSyncAccum += dt;
    if (this.hudSyncAccum >= 0.05) {
      this.hudSyncAccum = 0;
      this.emitHUDState();
    }
  }

  private updateGameOver(dt: number): void {
    this.crashTimer += dt;
    this.updateParticles(dt);

    // Dramatic tumble pose & stunned cartoon cat face
    this.character.group.rotation.x = THREE.MathUtils.damp(
      this.character.group.rotation.x,
      -Math.PI * 0.42,
      8,
      dt
    );
    this.character.group.position.y = THREE.MathUtils.damp(
      this.character.group.position.y,
      0.35,
      8,
      dt
    );
    this.animateCatFace(dt, 'crash', 0);
    this.animateCatTail(dt, 0, 'crash');

    if (this.cameraShake > 0) {
      this.cameraShake = Math.max(0, this.cameraShake - dt * 2.5);
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShake * 0.4;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShake * 0.4;
    }
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, 7.6, 5, dt);
    this.camera.lookAt(this.playerX, 0.9, 0);
  }

  private scrollTrack(step: number): void {
    let minZ = Infinity;
    for (let i = 0; i < this.trackSegments.length; i++) {
      this.trackSegments[i].z += step;
      if (this.trackSegments[i].z < minZ) {
        minZ = this.trackSegments[i].z;
      }
    }
    for (let i = 0; i < this.trackSegments.length; i++) {
      const seg = this.trackSegments[i];
      if (seg.z > TRACK_SEGMENT_LENGTH + 6) {
        seg.z = minZ - TRACK_SEGMENT_LENGTH;
        minZ = seg.z;
      }
      seg.group.position.z = seg.z;
    }
  }

  private getGroundSupportHeight(px: number, py: number): number {
    let maxSupport = 0;
    const trainKinds: ObstacleKind[] = ['train_static', 'train_ramp', 'train_moving'];
    for (const kind of trainKinds) {
      const pool = this.obstaclePools[kind];
      for (let i = 0; i < pool.length; i++) {
        const obs = pool[i];
        if (!obs.active || obs.smashed) continue;
        if (Math.abs(px - obs.x) > 1.05) continue;

        const halfLen = 6.75;
        // Main train roof
        if (obs.z - halfLen <= 0.35 && obs.z + halfLen >= -0.35) {
          if (py >= TRAIN_HEIGHT - 0.6) {
            maxSupport = Math.max(maxSupport, TRAIN_HEIGHT);
          }
        }
        // Boarding ramp in front of train_ramp (+6.75 to +11.25 relative to obs.z)
        if (kind === 'train_ramp') {
          const rampStart = obs.z + halfLen;
          const rampEnd = rampStart + 4.5;
          if (0 >= rampStart - 0.25 && 0 <= rampEnd + 0.25) {
            const t = THREE.MathUtils.clamp((0 - rampStart) / 4.5, 0, 1);
            const rampY = TRAIN_HEIGHT * (1 - t);
            if (py >= rampY - 0.65) {
              maxSupport = Math.max(maxSupport, rampY);
            }
          }
        }
      }
    }
    return maxSupport;
  }

  private updateObstacles(dt: number, forwardStep: number, boostActive: boolean): void {
    const playerBottom = this.playerY;
    const playerTop = this.playerY + (this.slideTimer > 0 ? 0.85 : 1.72);

    (Object.keys(this.obstaclePools) as ObstacleKind[]).forEach((kind) => {
      const pool = this.obstaclePools[kind];
      for (let i = 0; i < pool.length; i++) {
        const obs = pool[i];
        if (!obs.active) continue;

        if (obs.smashed) {
          obs.mesh.position.x += obs.smashVx * dt;
          obs.mesh.position.y += obs.smashVy * dt;
          obs.mesh.position.z += (forwardStep * 0.5);
          obs.smashVy -= 26 * dt;
          obs.mesh.rotation.x += obs.smashRot * dt;
          obs.mesh.rotation.z += obs.smashRot * 0.7 * dt;
          if (obs.mesh.position.y < -6 || obs.mesh.position.z > 25) {
            obs.active = false;
            obs.mesh.visible = false;
          }
          continue;
        }

        obs.z += forwardStep + obs.extraSpeed * dt;
        obs.mesh.position.z = obs.z;

        if (obs.z > 24) {
          obs.active = false;
          obs.mesh.visible = false;
          continue;
        }

        // Collision Check around z = 0
        const laneMatch = Math.abs(this.playerX - obs.x) < 0.9;
        if (!laneMatch) continue;

        let hit = false;
        if (kind === 'low_barrier') {
          if (Math.abs(obs.z) < 0.55 && playerBottom < 0.96) {
            hit = true;
          }
        } else if (kind === 'high_barrier') {
          if (Math.abs(obs.z) < 0.55 && playerTop > 1.18 && playerBottom < 2.35) {
            hit = true;
          }
        } else if (kind === 'tall_barrier') {
          if (Math.abs(obs.z) < 0.55 && playerBottom < 2.25) {
            hit = true;
          }
        } else {
          // Train collision (if not safely riding roof or boarding ramp)
          const halfLen = 6.6;
          if (obs.z - halfLen < 0.32 && obs.z + halfLen > -0.32) {
            if (playerBottom < TRAIN_HEIGHT - 0.6) {
              hit = true;
            }
          }
        }

        if (hit) {
          if (boostActive) {
            obs.smashed = true;
            obs.smashVx = (obs.x >= 0 ? 1 : -1) * (10 + Math.random() * 6);
            obs.smashVy = 14 + Math.random() * 6;
            obs.smashRot = (Math.random() > 0.5 ? 1 : -1) * 7;
            this.cameraShake = 0.45;
            soundEngine.playBoostSmash();
            this.spawnBurst(obs.x, 1.3, 0, 14, 0xf97316, 0.18);
          } else {
            this.triggerGameOver();
            return;
          }
        }
      }
    });
  }

  private updateCoins(dt: number, forwardStep: number): void {
    const magnetOn = this.magnetTimer > 0;
    const playerCenterY = this.playerY + (this.slideTimer > 0 ? 0.5 : 1.0);

    for (let i = 0; i < this.coinPool.length; i++) {
      const c = this.coinPool[i];
      if (!c.active) continue;

      c.z += forwardStep;

      // Magnet attraction across all lanes within 14 units
      if (magnetOn && c.z > -15 && c.z < 3.5) {
        c.attracted = true;
      }

      if (c.attracted) {
        c.x = THREE.MathUtils.damp(c.x, this.playerX, 16, dt);
        c.y = THREE.MathUtils.damp(c.y, playerCenterY, 16, dt);
        c.z = THREE.MathUtils.damp(c.z, 0, 16, dt);
      } else {
        c.y = c.baseY + Math.sin(this.elapsed * 4.5 + i) * 0.1;
      }

      c.mesh.position.set(c.x, c.y, c.z);
      c.mesh.rotation.y = this.elapsed * 3.8 + i * 0.4;

      if (c.z > 14) {
        c.active = false;
        c.mesh.visible = false;
        continue;
      }

      // Pickup distance check
      const dx = c.x - this.playerX;
      const dy = c.y - playerCenterY;
      const dz = c.z;
      if (dx * dx + dy * dy + dz * dz < 1.35) {
        c.active = false;
        c.mesh.visible = false;
        this.coins += 1;
        soundEngine.playCoin();
        this.spawnBurst(c.x, c.y, 0, 6, 0xfacc15, 0.11);
      }
    }
  }

  private updatePowerups(dt: number, forwardStep: number): void {
    const playerCenterY = this.playerY + 1.0;

    (['magnet', 'boost'] as PowerupKind[]).forEach((kind) => {
      const pool = this.powerupPools[kind];
      for (let i = 0; i < pool.length; i++) {
        const p = pool[i];
        if (!p.active) continue;

        p.z += forwardStep;
        const bobY = p.y + Math.sin(this.elapsed * 3.5 + i) * 0.16;
        p.mesh.position.set(p.x, bobY, p.z);
        p.mesh.rotation.y = this.elapsed * 2.8;

        if (p.z > 14) {
          p.active = false;
          p.mesh.visible = false;
          continue;
        }

        const dx = p.x - this.playerX;
        const dy = bobY - playerCenterY;
        const dz = p.z;
        if (dx * dx + dy * dy + dz * dz < 1.8) {
          p.active = false;
          p.mesh.visible = false;
          soundEngine.playPowerup();
          if (kind === 'magnet') {
            this.magnetTimer = MAGNET_DURATION;
            this.spawnBurst(p.x, bobY, 0, 14, 0x38bdf8, 0.15);
          } else {
            this.boostTimer = BOOST_DURATION;
            this.spawnBurst(p.x, bobY, 0, 16, 0xf59e0b, 0.16);
          }
          this.emitHUDState();
        }
      }
    });
  }

  private triggerGameOver(): void {
    this.phase = 'gameover';
    this.cameraShake = 0.85;
    this.crashTimer = 0;
    soundEngine.playCrash();
    this.spawnBurst(this.playerX, this.playerY + 1.0, 0, 20, 0xf97316, 0.17);

    if (this.score >= this.bestScore) {
      this.bestScore = this.score;
      try {
        localStorage.setItem(BEST_SCORE_KEY, String(this.bestScore));
      } catch {
        // Ignore storage restrictions
      }
    }
    this.emitHUDState();
  }

  // Character Procedural Limb, Tail & Facial Animations ----------------------

  private animateCatTail(
    dt: number,
    lateralVel: number,
    mode: 'run' | 'jump' | 'slide' | 'crash'
  ): void {
    const turnBias = THREE.MathUtils.clamp(-lateralVel * 0.06, -0.55, 0.55);

    if (mode === 'slide') {
      this.character.tailBase.rotation.x = THREE.MathUtils.damp(
        this.character.tailBase.rotation.x,
        -0.45,
        14,
        dt
      );
      this.character.tailBase.rotation.y = THREE.MathUtils.damp(
        this.character.tailBase.rotation.y,
        turnBias + Math.sin(this.elapsed * 9) * 0.12,
        14,
        dt
      );
      this.character.tailMid.rotation.x = THREE.MathUtils.damp(this.character.tailMid.rotation.x, 0.25, 14, dt);
      this.character.tailMid.rotation.y = THREE.MathUtils.damp(this.character.tailMid.rotation.y, Math.sin(this.elapsed * 9 - 0.8) * 0.18, 14, dt);
      this.character.tailTip.rotation.x = THREE.MathUtils.damp(this.character.tailTip.rotation.x, 0.35, 14, dt);
      this.character.tailTip.rotation.y = THREE.MathUtils.damp(this.character.tailTip.rotation.y, Math.sin(this.elapsed * 9 - 1.6) * 0.22, 14, dt);
      return;
    }

    if (mode === 'jump') {
      this.character.tailBase.rotation.x = THREE.MathUtils.damp(
        this.character.tailBase.rotation.x,
        this.velocityY > 0 ? 0.55 : -0.35,
        12,
        dt
      );
      this.character.tailBase.rotation.y = THREE.MathUtils.damp(this.character.tailBase.rotation.y, turnBias, 12, dt);
      this.character.tailMid.rotation.x = THREE.MathUtils.damp(this.character.tailMid.rotation.x, 0.38, 12, dt);
      this.character.tailMid.rotation.y = THREE.MathUtils.damp(this.character.tailMid.rotation.y, turnBias * 0.5, 12, dt);
      this.character.tailTip.rotation.x = THREE.MathUtils.damp(this.character.tailTip.rotation.x, 0.45, 12, dt);
      return;
    }

    if (mode === 'crash') {
      this.character.tailBase.rotation.x = THREE.MathUtils.damp(this.character.tailBase.rotation.x, 0.7, 10, dt);
      this.character.tailMid.rotation.x = THREE.MathUtils.damp(this.character.tailMid.rotation.x, 0.65, 10, dt);
      this.character.tailTip.rotation.x = THREE.MathUtils.damp(this.character.tailTip.rotation.x, 0.6, 10, dt);
      return;
    }

    // Energetic travelling sine wave along 3 tail segments while running/idling
    const t = this.elapsed * 8.5;
    this.character.tailBase.rotation.x = THREE.MathUtils.damp(
      this.character.tailBase.rotation.x,
      0.32 + Math.sin(t * 0.5) * 0.08,
      14,
      dt
    );
    this.character.tailBase.rotation.y = THREE.MathUtils.damp(
      this.character.tailBase.rotation.y,
      Math.sin(t) * 0.34 + turnBias,
      14,
      dt
    );
    this.character.tailMid.rotation.x = THREE.MathUtils.damp(this.character.tailMid.rotation.x, 0.3, 14, dt);
    this.character.tailMid.rotation.y = THREE.MathUtils.damp(
      this.character.tailMid.rotation.y,
      Math.sin(t - 0.9) * 0.42 + turnBias * 0.4,
      14,
      dt
    );
    this.character.tailTip.rotation.x = THREE.MathUtils.damp(this.character.tailTip.rotation.x, 0.34, 14, dt);
    this.character.tailTip.rotation.y = THREE.MathUtils.damp(
      this.character.tailTip.rotation.y,
      Math.sin(t - 1.8) * 0.48,
      14,
      dt
    );
  }

  private animateCatFace(
    dt: number,
    mode: 'run' | 'jump' | 'slide' | 'crash',
    lateralVel: number
  ): void {
    // Natural blink scheduler
    this.blinkTimer += dt;
    let isBlinking = false;
    if (this.blinkTimer >= this.nextBlinkDelay) {
      if (this.blinkTimer <= this.nextBlinkDelay + 0.13) {
        isBlinking = true;
      } else {
        this.blinkTimer = 0;
        this.nextBlinkDelay = 2.0 + Math.random() * 2.4;
      }
    }

    const headTurn = THREE.MathUtils.clamp(-lateralVel * 0.032, -0.32, 0.32);
    this.character.head.rotation.y = THREE.MathUtils.damp(
      this.character.head.rotation.y,
      headTurn,
      14,
      dt
    );

    const funnyLanding = this.landingTimer > 0 && mode !== 'crash';

    if (mode === 'crash') {
      // Goofy stunned cartoon cat face
      this.character.leftEyelid.rotation.x = THREE.MathUtils.damp(this.character.leftEyelid.rotation.x, -Math.PI * 0.58, 16, dt);
      this.character.rightEyelid.rotation.x = THREE.MathUtils.damp(this.character.rightEyelid.rotation.x, -Math.PI * 0.58, 16, dt);
      this.character.leftEye.scale.setScalar(THREE.MathUtils.damp(this.character.leftEye.scale.x, 1.25, 16, dt));
      this.character.rightEye.scale.setScalar(THREE.MathUtils.damp(this.character.rightEye.scale.x, 1.25, 16, dt));
      this.character.leftPupil.scale.setScalar(0.55);
      this.character.rightPupil.scale.setScalar(0.55);
      this.character.leftBrow.position.y = 0.45;
      this.character.rightBrow.position.y = 0.43;
      this.character.leftBrow.rotation.z = Math.PI / 2 + 0.35;
      this.character.rightBrow.rotation.z = Math.PI / 2 - 0.35;
      this.character.smileMouth.visible = false;
      this.character.oMouth.visible = true;
      this.character.leftEar.rotation.z = 0.75;
      this.character.rightEar.rotation.z = -0.75;
      return;
    }

    if (funnyLanding) {
      // Funny landing expression: goofy cross-eyed squint, staggered brows, floppy ears & O-mouth!
      const wobble = Math.sin(this.landingTimer * 28) * 0.14;
      this.character.leftEyelid.rotation.x = THREE.MathUtils.damp(this.character.leftEyelid.rotation.x, -0.32, 22, dt);
      this.character.rightEyelid.rotation.x = THREE.MathUtils.damp(this.character.rightEyelid.rotation.x, -0.58, 22, dt);
      this.character.leftEye.scale.setScalar(THREE.MathUtils.damp(this.character.leftEye.scale.x, 1.15, 18, dt));
      this.character.rightEye.scale.setScalar(THREE.MathUtils.damp(this.character.rightEye.scale.x, 0.92, 18, dt));
      // Slight comical cross-eye pupil shift
      this.character.leftPupil.position.x = THREE.MathUtils.damp(this.character.leftPupil.position.x, 0.036, 22, dt);
      this.character.rightPupil.position.x = THREE.MathUtils.damp(this.character.rightPupil.position.x, -0.036, 22, dt);
      this.character.leftPupil.scale.setScalar(0.78);
      this.character.rightPupil.scale.setScalar(1.05);

      this.character.leftBrow.position.y = THREE.MathUtils.damp(this.character.leftBrow.position.y, 0.44, 22, dt);
      this.character.rightBrow.position.y = THREE.MathUtils.damp(this.character.rightBrow.position.y, 0.37, 22, dt);
      this.character.leftBrow.rotation.z = THREE.MathUtils.damp(this.character.leftBrow.rotation.z, Math.PI / 2 + 0.42, 22, dt);
      this.character.rightBrow.rotation.z = THREE.MathUtils.damp(this.character.rightBrow.rotation.z, Math.PI / 2 + 0.25, 22, dt);

      this.character.smileMouth.visible = false;
      this.character.oMouth.visible = true;
      this.character.oMouth.scale.set(1.1 + wobble, 0.9 - wobble, 0.55);

      this.character.leftEar.rotation.z = THREE.MathUtils.damp(this.character.leftEar.rotation.z, 0.68 + wobble, 20, dt);
      this.character.rightEar.rotation.z = THREE.MathUtils.damp(this.character.rightEar.rotation.z, -0.68 - wobble, 20, dt);
      return;
    }

    // Restore normal pupil placement & scale
    this.character.leftPupil.position.x = THREE.MathUtils.damp(this.character.leftPupil.position.x, 0.012, 16, dt);
    this.character.rightPupil.position.x = THREE.MathUtils.damp(this.character.rightPupil.position.x, -0.012, 16, dt);
    this.character.leftPupil.scale.setScalar(1.0);
    this.character.rightPupil.scale.setScalar(1.0);

    if (mode === 'jump') {
      // Surprised / excited wide eyes + perked ears + O-mouth
      this.character.leftEyelid.rotation.x = THREE.MathUtils.damp(this.character.leftEyelid.rotation.x, -Math.PI * 0.62, 18, dt);
      this.character.rightEyelid.rotation.x = THREE.MathUtils.damp(this.character.rightEyelid.rotation.x, -Math.PI * 0.62, 18, dt);
      this.character.leftEye.scale.setScalar(THREE.MathUtils.damp(this.character.leftEye.scale.x, 1.16, 16, dt));
      this.character.rightEye.scale.setScalar(THREE.MathUtils.damp(this.character.rightEye.scale.x, 1.16, 16, dt));
      this.character.leftBrow.position.y = THREE.MathUtils.damp(this.character.leftBrow.position.y, 0.445, 16, dt);
      this.character.rightBrow.position.y = THREE.MathUtils.damp(this.character.rightBrow.position.y, 0.445, 16, dt);
      this.character.leftBrow.rotation.z = THREE.MathUtils.damp(this.character.leftBrow.rotation.z, Math.PI / 2 + 0.16, 16, dt);
      this.character.rightBrow.rotation.z = THREE.MathUtils.damp(this.character.rightBrow.rotation.z, Math.PI / 2 - 0.16, 16, dt);
      this.character.smileMouth.visible = false;
      this.character.oMouth.visible = true;
      this.character.oMouth.scale.set(0.95, 1.25, 0.55);
      this.character.leftEar.rotation.z = THREE.MathUtils.damp(this.character.leftEar.rotation.z, 0.14, 16, dt);
      this.character.rightEar.rotation.z = THREE.MathUtils.damp(this.character.rightEar.rotation.z, -0.14, 16, dt);
      this.character.leftEar.rotation.x = THREE.MathUtils.damp(this.character.leftEar.rotation.x, -0.05, 16, dt);
      this.character.rightEar.rotation.x = THREE.MathUtils.damp(this.character.rightEar.rotation.x, -0.05, 16, dt);
    } else if (mode === 'slide') {
      // Determined squinted slide + ears swept back!
      this.character.leftEyelid.rotation.x = THREE.MathUtils.damp(this.character.leftEyelid.rotation.x, -0.45, 18, dt);
      this.character.rightEyelid.rotation.x = THREE.MathUtils.damp(this.character.rightEyelid.rotation.x, -0.45, 18, dt);
      this.character.leftEye.scale.setScalar(THREE.MathUtils.damp(this.character.leftEye.scale.x, 1.0, 16, dt));
      this.character.rightEye.scale.setScalar(THREE.MathUtils.damp(this.character.rightEye.scale.x, 1.0, 16, dt));
      this.character.leftBrow.position.y = THREE.MathUtils.damp(this.character.leftBrow.position.y, 0.39, 18, dt);
      this.character.rightBrow.position.y = THREE.MathUtils.damp(this.character.rightBrow.position.y, 0.39, 18, dt);
      this.character.leftBrow.rotation.z = THREE.MathUtils.damp(this.character.leftBrow.rotation.z, Math.PI / 2 - 0.22, 18, dt);
      this.character.rightBrow.rotation.z = THREE.MathUtils.damp(this.character.rightBrow.rotation.z, Math.PI / 2 + 0.22, 18, dt);
      this.character.smileMouth.visible = true;
      this.character.oMouth.visible = false;
      this.character.leftEar.rotation.z = THREE.MathUtils.damp(this.character.leftEar.rotation.z, 0.52, 18, dt);
      this.character.rightEar.rotation.z = THREE.MathUtils.damp(this.character.rightEar.rotation.z, -0.52, 18, dt);
      this.character.leftEar.rotation.x = THREE.MathUtils.damp(this.character.leftEar.rotation.x, 0.55, 18, dt);
      this.character.rightEar.rotation.x = THREE.MathUtils.damp(this.character.rightEar.rotation.x, 0.55, 18, dt);
    } else {
      // Cheerful running expression with natural blinks & bouncy ears
      const lidTarget = isBlinking ? 0.12 : -Math.PI * 0.55;
      this.character.leftEyelid.rotation.x = THREE.MathUtils.damp(this.character.leftEyelid.rotation.x, lidTarget, 26, dt);
      this.character.rightEyelid.rotation.x = THREE.MathUtils.damp(this.character.rightEyelid.rotation.x, lidTarget, 26, dt);
      this.character.leftEye.scale.setScalar(THREE.MathUtils.damp(this.character.leftEye.scale.x, 1.0, 14, dt));
      this.character.rightEye.scale.setScalar(THREE.MathUtils.damp(this.character.rightEye.scale.x, 1.0, 14, dt));
      this.character.leftBrow.position.y = THREE.MathUtils.damp(this.character.leftBrow.position.y, 0.405, 14, dt);
      this.character.rightBrow.position.y = THREE.MathUtils.damp(this.character.rightBrow.position.y, 0.405, 14, dt);
      this.character.leftBrow.rotation.z = THREE.MathUtils.damp(this.character.leftBrow.rotation.z, Math.PI / 2 + 0.08, 14, dt);
      this.character.rightBrow.rotation.z = THREE.MathUtils.damp(this.character.rightBrow.rotation.z, Math.PI / 2 - 0.08, 14, dt);
      this.character.smileMouth.visible = true;
      this.character.oMouth.visible = false;

      const earBounce = Math.sin(this.runCycle * 2) * 0.06;
      this.character.leftEar.rotation.z = THREE.MathUtils.damp(this.character.leftEar.rotation.z, 0.26 + earBounce, 14, dt);
      this.character.rightEar.rotation.z = THREE.MathUtils.damp(this.character.rightEar.rotation.z, -0.26 - earBounce, 14, dt);
      this.character.leftEar.rotation.x = THREE.MathUtils.damp(this.character.leftEar.rotation.x, -0.06, 14, dt);
      this.character.rightEar.rotation.x = THREE.MathUtils.damp(this.character.rightEar.rotation.x, -0.06, 14, dt);
    }
  }

  private animateCharacterJog(dt: number, lateralVel: number): void {
    const rate = 8.4 + (this.speed - BASE_SPEED) * 0.25;
    this.runCycle += dt * rate;

    const s = Math.sin(this.runCycle);
    const c = Math.cos(this.runCycle);

    // Smoothly restore slide offsets + lively cat bounce
    this.character.hips.position.y = THREE.MathUtils.damp(
      this.character.hips.position.y,
      0.88 + Math.abs(c) * 0.09,
      18,
      dt
    );
    this.character.hips.rotation.x = THREE.MathUtils.damp(this.character.hips.rotation.x, 0, 14, dt);
    this.character.torso.rotation.x = THREE.MathUtils.damp(
      this.character.torso.rotation.x,
      -0.18,
      14,
      dt
    );
    this.character.torso.rotation.y = THREE.MathUtils.damp(
      this.character.torso.rotation.y,
      s * 0.14 - lateralVel * 0.016,
      14,
      dt
    );

    this.character.leftLeg.rotation.x = s * 0.88;
    this.character.rightLeg.rotation.x = -s * 0.88;
    this.character.leftShin.rotation.x = Math.max(0, -c * 0.95);
    this.character.rightShin.rotation.x = Math.max(0, c * 0.95);

    this.character.leftArm.rotation.x = -s * 0.92;
    this.character.rightArm.rotation.x = s * 0.92;
    this.character.leftArm.rotation.z = -0.18;
    this.character.rightArm.rotation.z = 0.18;

    this.animateCatTail(dt, lateralVel, 'run');
    this.animateCatFace(dt, 'run', lateralVel);
  }

  private animateCharacterJump(dt: number): void {
    this.character.hips.position.y = THREE.MathUtils.damp(this.character.hips.position.y, 0.92, 14, dt);
    this.character.hips.rotation.x = THREE.MathUtils.damp(this.character.hips.rotation.x, 0, 12, dt);
    this.character.torso.rotation.x = THREE.MathUtils.damp(
      this.character.torso.rotation.x,
      this.velocityY > 0 ? -0.14 : 0.14,
      10,
      dt
    );
    this.character.leftLeg.rotation.x = THREE.MathUtils.damp(this.character.leftLeg.rotation.x, 0.68, 14, dt);
    this.character.rightLeg.rotation.x = THREE.MathUtils.damp(this.character.rightLeg.rotation.x, -0.38, 14, dt);
    this.character.leftShin.rotation.x = THREE.MathUtils.damp(this.character.leftShin.rotation.x, 0.95, 14, dt);
    this.character.rightShin.rotation.x = THREE.MathUtils.damp(this.character.rightShin.rotation.x, 0.45, 14, dt);
    this.character.leftArm.rotation.x = THREE.MathUtils.damp(this.character.leftArm.rotation.x, -1.7, 14, dt);
    this.character.rightArm.rotation.x = THREE.MathUtils.damp(this.character.rightArm.rotation.x, -1.7, 14, dt);

    this.animateCatTail(dt, 0, 'jump');
    this.animateCatFace(dt, 'jump', 0);
  }

  private animateCharacterSlide(dt: number): void {
    // Low sleek cartoon cat slide
    this.character.hips.position.y = THREE.MathUtils.damp(this.character.hips.position.y, 0.34, 20, dt);
    this.character.hips.rotation.x = THREE.MathUtils.damp(this.character.hips.rotation.x, 0.98, 20, dt);
    this.character.torso.rotation.x = THREE.MathUtils.damp(this.character.torso.rotation.x, 0.2, 20, dt);
    this.character.leftLeg.rotation.x = THREE.MathUtils.damp(this.character.leftLeg.rotation.x, 0.45, 20, dt);
    this.character.rightLeg.rotation.x = THREE.MathUtils.damp(this.character.rightLeg.rotation.x, -0.15, 20, dt);
    this.character.leftShin.rotation.x = THREE.MathUtils.damp(this.character.leftShin.rotation.x, 0.1, 20, dt);
    this.character.rightShin.rotation.x = THREE.MathUtils.damp(this.character.rightShin.rotation.x, 0.9, 20, dt);
    this.character.leftArm.rotation.x = THREE.MathUtils.damp(this.character.leftArm.rotation.x, -0.7, 20, dt);
    this.character.rightArm.rotation.x = THREE.MathUtils.damp(this.character.rightArm.rotation.x, -0.7, 20, dt);

    this.animateCatTail(dt, 0, 'slide');
    this.animateCatFace(dt, 'slide', 0);
  }

  private emitHUDState(): void {
    this.callbacks.onStateChange({
      phase: this.phase,
      score: this.score,
      bestScore: this.bestScore,
      coins: this.coins,
      distance: Math.floor(this.distance),
      speedMultiplier: Number((this.speed / BASE_SPEED).toFixed(1)),
      isNewBest: this.isNewBest,
      activePowerups: {
        magnetRemaining: this.magnetTimer,
        magnetDuration: MAGNET_DURATION,
        boostRemaining: this.boostTimer,
        boostDuration: BOOST_DURATION,
      },
      webglLost: this.webglLost,
    });
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    window.removeEventListener('resize', this.handleResize);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);

    this.character.dispose();
    this.assetFactory.dispose();
    this.particleMesh.geometry.dispose();
    (this.particleMesh.material as THREE.Material).dispose();
    this.envRenderTarget.dispose();

    this.scene.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry?.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m) => m.dispose());
        } else {
          obj.material?.dispose();
        }
      }
    });

    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
