import * as THREE from 'three';

export interface ProceduralTextureSet {
  trackMap: THREE.CanvasTexture;
  hazardMap: THREE.CanvasTexture;
  trainSideMap: THREE.CanvasTexture;
  buildingMaps: THREE.CanvasTexture[];
  contactShadowMap: THREE.CanvasTexture;
  dispose: () => void;
}

function finalizeColorTexture(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  repeatX = 1,
  repeatY = 1
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = anisotropy;
  if (repeatX !== 1 || repeatY !== 1) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeatX, repeatY);
  }
  tex.needsUpdate = true;
  return tex;
}

function createTrackCanvas(): HTMLCanvasElement {
  const w = 1024;
  const h = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Base gravel ballast bed
  ctx.fillStyle = '#334155';
  ctx.fillRect(0, 0, w, h);

  // Subtle ballast speckles
  for (let i = 0; i < 4200; i++) {
    const x = (i * 97) % w;
    const y = ((i * 233) % h);
    const shade = (i % 3 === 0) ? '#475569' : (i % 3 === 1 ? '#1e293b' : '#64748b');
    ctx.fillStyle = shade;
    ctx.fillRect(x, y, 4, 4);
  }

  // Side concrete curbs
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(0, 0, 76, h);
  ctx.fillRect(w - 76, 0, 76, h);

  // Safety yellow-orange inner curb warning strip
  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(76, 0, 14, h);
  ctx.fillRect(w - 90, 0, 14, h);

  // 3 track lane beds (width mapped across 12 world units: center at 0.283, 0.5, 0.717)
  const laneCenters = [w * (1 / 2 - 2.6 / 12), w * 0.5, w * (1 / 2 + 2.6 / 12)];
  const sleeperWidth = 175;
  const sleeperHeight = 22;

  for (const cx of laneCenters) {
    // Darker track gravel corridor
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(cx - 95, 0, 190, h);

    // Wooden railway sleepers
    const sleeperCount = 16;
    const step = h / sleeperCount;
    for (let s = 0; s < sleeperCount; s++) {
      const sy = s * step + 10;
      ctx.fillStyle = '#5c4033';
      ctx.fillRect(cx - sleeperWidth / 2, sy, sleeperWidth, sleeperHeight);
      ctx.fillStyle = '#785543';
      ctx.fillRect(cx - sleeperWidth / 2, sy, sleeperWidth, 5);
    }

    // Twin steel rails per lane
    const railOffset = 58;
    for (const side of [-1, 1]) {
      const rx = cx + side * railOffset - 7;
      ctx.fillStyle = '#64748b';
      ctx.fillRect(rx, 0, 14, h);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(rx + 3, 0, 6, h);
    }
  }

  // Subtle glowing cyan lane guide lines between lanes
  ctx.fillStyle = 'rgba(56, 189, 248, 0.35)';
  ctx.fillRect(w * (0.5 - 1.3 / 12) - 3, 0, 6, h);
  ctx.fillRect(w * (0.5 + 1.3 / 12) - 3, 0, 6, h);

  return canvas;
}

function createHazardCanvas(): HTMLCanvasElement {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#facc15';
  ctx.fillRect(0, 0, size, size);

  ctx.fillStyle = '#1e293b';
  const stripeW = 36;
  for (let i = -size; i < size * 2; i += stripeW * 2) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + stripeW, 0);
    ctx.lineTo(i + stripeW - size, size);
    ctx.lineTo(i - size, size);
    ctx.closePath();
    ctx.fill();
  }
  return canvas;
}

function createTrainSideCanvas(): HTMLCanvasElement {
  const w = 512;
  const h = 256;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Clean silver-white metro body
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#f8fafc');
  grad.addColorStop(0.55, '#e2e8f0');
  grad.addColorStop(1, '#94a3b8');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Express accent stripe
  ctx.fillStyle = '#0ea5e9';
  ctx.fillRect(0, 148, w, 28);
  ctx.fillStyle = '#f97316';
  ctx.fillRect(0, 176, w, 10);

  // Tinted passenger windows
  const winW = 72;
  const winH = 68;
  for (let i = 0; i < 5; i++) {
    const wx = 26 + i * 96;
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.roundRect(wx, 52, winW, winH, 10);
    ctx.fill();

    // Window sky reflection
    ctx.fillStyle = 'rgba(56, 189, 248, 0.35)';
    ctx.beginPath();
    ctx.roundRect(wx + 6, 58, winW - 18, 22, 6);
    ctx.fill();
  }

  return canvas;
}

function createBuildingCanvas(baseHex: string, accentHex: string): HTMLCanvasElement {
  const w = 256;
  const h = 512;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, w, h);

  // Architectural trim bands
  ctx.fillStyle = accentHex;
  ctx.fillRect(0, 0, w, 22);
  ctx.fillRect(0, h - 30, w, 30);

  // Window grid
  const cols = 4;
  const rows = 10;
  const padX = 18;
  const padY = 44;
  const cellW = (w - padX * 2) / cols;
  const cellH = (h - padY - 46) / rows;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const lit = (r * 7 + c * 13) % 5 !== 0;
      ctx.fillStyle = lit ? '#fef08a' : '#1e293b';
      if (lit && (r + c) % 3 === 0) {
        ctx.fillStyle = '#7dd3fc';
      }
      ctx.fillRect(padX + c * cellW + 6, padY + r * cellH + 6, cellW - 12, cellH - 14);
    }
  }

  return canvas;
}

function createContactShadowCanvas(): HTMLCanvasElement {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 6, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(15, 23, 42, 0.72)');
  grad.addColorStop(0.55, 'rgba(15, 23, 42, 0.3)');
  grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  return canvas;
}

export function createProceduralTextures(maxAnisotropy: number): ProceduralTextureSet {
  const aniso = Math.min(maxAnisotropy || 4, 8);

  const trackMap = finalizeColorTexture(createTrackCanvas(), aniso, 1, 3);
  const hazardMap = finalizeColorTexture(createHazardCanvas(), aniso, 2, 1);
  const trainSideMap = finalizeColorTexture(createTrainSideCanvas(), aniso, 1, 1);

  const buildingPalettes: [string, string][] = [
    ['#3b82f6', '#1d4ed8'],
    ['#ec4899', '#9d174d'],
    ['#14b8a6', '#0f766e'],
  ];
  const buildingMaps = buildingPalettes.map(([b, a]) =>
    finalizeColorTexture(createBuildingCanvas(b, a), aniso, 1, 1)
  );

  const contactShadowMap = new THREE.CanvasTexture(createContactShadowCanvas());
  contactShadowMap.needsUpdate = true;

  return {
    trackMap,
    hazardMap,
    trainSideMap,
    buildingMaps,
    contactShadowMap,
    dispose: () => {
      trackMap.dispose();
      hazardMap.dispose();
      trainSideMap.dispose();
      buildingMaps.forEach((m) => m.dispose());
      contactShadowMap.dispose();
    },
  };
}
