import * as THREE from 'three';
import { ProceduralTextureSet } from './textures';
import { ObstacleKind, PowerupKind } from './types';

export const LANE_WIDTH = 2.6;
export const LANE_POSITIONS = [-LANE_WIDTH, 0, LANE_WIDTH] as const;
export const TRACK_SEGMENT_LENGTH = 30;
export const TRAIN_HEIGHT = 2.7;

export interface CharacterRig {
  group: THREE.Group;
  hips: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftEar: THREE.Group;
  rightEar: THREE.Group;
  leftEye: THREE.Group;
  rightEye: THREE.Group;
  leftPupil: THREE.Mesh;
  rightPupil: THREE.Mesh;
  leftEyelid: THREE.Mesh;
  rightEyelid: THREE.Mesh;
  leftBrow: THREE.Mesh;
  rightBrow: THREE.Mesh;
  smileMouth: THREE.Mesh;
  oMouth: THREE.Mesh;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  leftShin: THREE.Group;
  rightLeg: THREE.Group;
  rightShin: THREE.Group;
  tailBase: THREE.Group;
  tailMid: THREE.Group;
  tailTip: THREE.Group;
  boostAura: THREE.Group;
  magnetAura: THREE.Mesh;
  dispose: () => void;
}

export function createCharacterRig(): CharacterRig {
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    materials.push(m);
    return m;
  };

  // Classic cartoon blue-grey cat palette
  const furBlueMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x627c9c, roughness: 0.72, metalness: 0.04 })
  );
  const furDarkMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x455b78, roughness: 0.74, metalness: 0.05 })
  );
  const whiteFurMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.65, metalness: 0.02 })
  );
  const pinkMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.42, metalness: 0.04 })
  );
  const eyeScleraMat = trackMat(
    new THREE.MeshPhysicalMaterial({
      color: 0xfefce8,
      roughness: 0.18,
      metalness: 0.02,
      clearcoat: 0.6,
    })
  );
  const eyeGreenMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x22c55e,
      emissive: 0x15803d,
      emissiveIntensity: 0.25,
      roughness: 0.15,
      metalness: 0.08,
    })
  );
  const pupilMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x090d16, roughness: 0.15, metalness: 0.1 })
  );
  const glintMat = trackMat(new THREE.MeshBasicMaterial({ color: 0xffffff }));
  const whiskerMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.45, metalness: 0.1 })
  );
  const mouthInteriorMat = trackMat(
    new THREE.MeshStandardMaterial({ color: 0x881337, roughness: 0.5, metalness: 0.02 })
  );

  const group = new THREE.Group();

  // Hips pivot at ~0.88 above ground
  const hips = new THREE.Group();
  hips.position.set(0, 0.88, 0);
  group.add(hips);

  // Rounded pelvis
  const pelvis = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.24, 14, 12)), furBlueMat);
  pelvis.scale.set(1.05, 0.85, 0.92);
  pelvis.castShadow = true;
  hips.add(pelvis);

  // Torso group
  const torso = new THREE.Group();
  torso.position.set(0, 0.08, 0);
  hips.add(torso);

  // Plump cartoon cat body
  const body = new THREE.Mesh(
    trackGeo(new THREE.CapsuleGeometry(0.24, 0.34, 8, 16)),
    furBlueMat
  );
  body.position.set(0, 0.28, 0);
  body.scale.set(1.06, 1.0, 0.94);
  body.castShadow = true;
  torso.add(body);

  // White belly / chest fur patch (facing -Z forward)
  const belly = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.23, 14, 12)),
    whiteFurMat
  );
  belly.position.set(0, 0.25, -0.09);
  belly.scale.set(0.84, 1.24, 0.72);
  torso.add(belly);

  // Cute furry neck ruff
  const neckRuff = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.17, 12, 10)),
    whiteFurMat
  );
  neckRuff.position.set(0, 0.52, -0.08);
  neckRuff.scale.set(1.05, 0.65, 0.78);
  torso.add(neckRuff);

  // Long Flexible 3-Segment Articulated Cat Tail (extends toward +Z behind runner)
  const tailBase = new THREE.Group();
  tailBase.position.set(0, 0.05, 0.2);
  hips.add(tailBase);

  const tailSegGeo1 = trackGeo(new THREE.CapsuleGeometry(0.055, 0.28, 5, 10));
  const tailMesh1 = new THREE.Mesh(tailSegGeo1, furBlueMat);
  tailMesh1.rotation.x = Math.PI / 2;
  tailMesh1.position.set(0, 0, 0.16);
  tailMesh1.castShadow = true;
  tailBase.add(tailMesh1);

  const tailMid = new THREE.Group();
  tailMid.position.set(0, 0, 0.34);
  tailBase.add(tailMid);

  const tailSegGeo2 = trackGeo(new THREE.CapsuleGeometry(0.05, 0.28, 5, 10));
  const tailMesh2 = new THREE.Mesh(tailSegGeo2, furBlueMat);
  tailMesh2.rotation.x = Math.PI / 2;
  tailMesh2.position.set(0, 0, 0.16);
  tailMesh2.castShadow = true;
  tailMid.add(tailMesh2);

  // Subtle dark stripe band on tail mid
  const tailBand = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.053, 0.053, 0.08, 10)),
    furDarkMat
  );
  tailBand.rotation.x = Math.PI / 2;
  tailBand.position.set(0, 0, 0.18);
  tailMid.add(tailBand);

  const tailTip = new THREE.Group();
  tailTip.position.set(0, 0, 0.34);
  tailMid.add(tailTip);

  const tailTipSeg = new THREE.Mesh(
    trackGeo(new THREE.CapsuleGeometry(0.048, 0.2, 5, 10)),
    furBlueMat
  );
  tailTipSeg.rotation.x = Math.PI / 2;
  tailTipSeg.position.set(0, 0, 0.12);
  tailTip.add(tailTipSeg);

  const tailTipWhite = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.075, 10, 10)),
    whiteFurMat
  );
  tailTipWhite.scale.set(0.95, 0.95, 1.35);
  tailTipWhite.position.set(0, 0, 0.26);
  tailTipWhite.castShadow = true;
  tailTip.add(tailTipWhite);

  // Head Group ----------------------------------------------------------------
  const head = new THREE.Group();
  head.position.set(0, 0.58, 0);
  torso.add(head);

  // Cartoon cat cranium
  const cranium = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.27, 20, 16)),
    furBlueMat
  );
  cranium.position.set(0, 0.22, 0);
  cranium.scale.set(1.12, 0.96, 0.98);
  cranium.castShadow = true;
  head.add(cranium);

  // Forehead tuft
  const tuft = new THREE.Mesh(trackGeo(new THREE.ConeGeometry(0.065, 0.15, 7)), furDarkMat);
  tuft.position.set(0, 0.49, -0.04);
  tuft.rotation.x = -0.35;
  head.add(tuft);

  // Fluffy side cheek tufts (blue-grey)
  for (const side of [-1, 1]) {
    const cheekTuft = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(0.07, 0.16, 7)),
      furBlueMat
    );
    cheekTuft.position.set(side * 0.28, 0.16, -0.02);
    cheekTuft.rotation.z = -side * 1.25;
    head.add(cheekTuft);
  }

  // White Muzzle & Chubby Cheek Puffs
  const muzzleLeft = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.115, 12, 10)),
    whiteFurMat
  );
  muzzleLeft.position.set(-0.085, 0.145, -0.225);
  muzzleLeft.scale.set(1.05, 0.88, 0.85);
  head.add(muzzleLeft);

  const muzzleRight = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.115, 12, 10)),
    whiteFurMat
  );
  muzzleRight.position.set(0.085, 0.145, -0.225);
  muzzleRight.scale.set(1.05, 0.88, 0.85);
  head.add(muzzleRight);

  const chin = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.095, 12, 10)),
    whiteFurMat
  );
  chin.position.set(0, 0.075, -0.21);
  chin.scale.set(1.15, 0.78, 0.85);
  head.add(chin);

  // Cute Pink Button Nose
  const nose = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.052, 12, 10)), pinkMat);
  nose.position.set(0, 0.19, -0.31);
  nose.scale.set(1.2, 0.88, 0.9);
  head.add(nose);

  // Cute Cartoon Mouths (smile + surprised/funny O-mouth)
  const smileMouth = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.065, 0.015, 8, 16, Math.PI)),
    mouthInteriorMat
  );
  smileMouth.position.set(0, 0.115, -0.285);
  smileMouth.rotation.z = Math.PI;
  head.add(smileMouth);

  const oMouth = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.055, 12, 10)),
    mouthInteriorMat
  );
  oMouth.position.set(0, 0.095, -0.285);
  oMouth.scale.set(0.95, 1.25, 0.55);
  oMouth.visible = false;
  head.add(oMouth);

  // Whiskers (3 per side)
  const whiskerGeo = trackGeo(new THREE.CylinderGeometry(0.006, 0.003, 0.24, 5));
  whiskerGeo.rotateZ(Math.PI / 2);
  for (const side of [-1, 1]) {
    const angles = [0.22, 0.0, -0.22];
    angles.forEach((ang, idx) => {
      const w = new THREE.Mesh(whiskerGeo, whiskerMat);
      w.position.set(side * 0.22, 0.15 + (1 - idx) * 0.025, -0.24);
      w.rotation.z = side * ang;
      w.rotation.y = -side * 0.22;
      head.add(w);
    });
  }

  // Large Expressive Green Cartoon Eyes + Articulated Eyelids & Brows
  const buildEye = (side: -1 | 1) => {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(side * 0.105, 0.275, -0.22);
    eyeGroup.rotation.y = side * -0.14;
    head.add(eyeGroup);

    const sclera = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.085, 14, 12)),
      eyeScleraMat
    );
    sclera.scale.set(0.92, 1.25, 0.52);
    eyeGroup.add(sclera);

    const iris = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.054, 12, 10)),
      eyeGreenMat
    );
    iris.scale.set(0.9, 1.18, 0.45);
    iris.position.set(-side * 0.012, 0, -0.032);
    eyeGroup.add(iris);

    const pupil = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.032, 10, 10)),
      pupilMat
    );
    pupil.scale.set(0.85, 1.15, 0.45);
    pupil.position.set(-side * 0.012, 0, -0.048);
    eyeGroup.add(pupil);

    const glint = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.014, 8, 8)), glintMat);
    glint.position.set(-side * 0.024, 0.028, -0.058);
    eyeGroup.add(glint);

    // Upper eyelid dome (rotates down to blink or squint)
    const eyelid = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.091, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.52)),
      furDarkMat
    );
    eyelid.scale.set(0.95, 1.26, 0.58);
    eyelid.rotation.x = -Math.PI * 0.55; // tucked up by default
    eyeGroup.add(eyelid);

    // Expressive eyebrow
    const brow = new THREE.Mesh(
      trackGeo(new THREE.CapsuleGeometry(0.018, 0.095, 4, 8)),
      furDarkMat
    );
    brow.rotation.z = Math.PI / 2;
    brow.position.set(side * 0.105, 0.405, -0.255);
    head.add(brow);

    return { eyeGroup, pupil, eyelid, brow };
  };

  const leftEyeParts = buildEye(-1);
  const rightEyeParts = buildEye(1);

  // Large Cat Ears with Pink Inner Ears
  const buildEar = (side: -1 | 1): THREE.Group => {
    const earGroup = new THREE.Group();
    earGroup.position.set(side * 0.19, 0.41, 0.01);
    earGroup.rotation.z = -side * 0.26;
    earGroup.rotation.x = -0.08;

    const outerEar = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(0.12, 0.29, 12)),
      furBlueMat
    );
    outerEar.scale.set(1.0, 1.0, 0.55);
    outerEar.position.set(0, 0.12, 0);
    outerEar.castShadow = true;
    earGroup.add(outerEar);

    const innerEar = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(0.075, 0.2, 10)),
      pinkMat
    );
    innerEar.scale.set(1.0, 1.0, 0.45);
    innerEar.position.set(0, 0.11, -0.028);
    earGroup.add(innerEar);

    head.add(earGroup);
    return earGroup;
  };

  const leftEar = buildEar(-1);
  const rightEar = buildEar(1);

  // Helper to build articulated cartoon arms + white glove paws
  const buildArm = (side: -1 | 1): THREE.Group => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.27, 0.46, 0);

    const armFur = new THREE.Mesh(
      trackGeo(new THREE.CapsuleGeometry(0.068, 0.24, 5, 10)),
      furBlueMat
    );
    armFur.position.set(0, -0.17, 0);
    armFur.castShadow = true;
    shoulder.add(armFur);

    // Cute white cat paw glove
    const paw = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.092, 12, 10)), whiteFurMat);
    paw.position.set(0, -0.36, -0.01);
    paw.scale.set(1.05, 1.1, 1.05);
    paw.castShadow = true;
    shoulder.add(paw);

    const thumb = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.042, 8, 8)), whiteFurMat);
    thumb.position.set(-side * 0.07, -0.34, -0.04);
    shoulder.add(thumb);

    torso.add(shoulder);
    return shoulder;
  };

  const leftArm = buildArm(-1);
  const rightArm = buildArm(1);

  // Helper to build articulated legs + big white cartoon hind paws
  const buildLeg = (side: -1 | 1): { hip: THREE.Group; shin: THREE.Group } => {
    const hip = new THREE.Group();
    hip.position.set(side * 0.135, -0.02, 0);
    hips.add(hip);

    const thigh = new THREE.Mesh(
      trackGeo(new THREE.CapsuleGeometry(0.088, 0.24, 5, 10)),
      furBlueMat
    );
    thigh.position.set(0, -0.18, 0);
    thigh.castShadow = true;
    hip.add(thigh);

    const shin = new THREE.Group();
    shin.position.set(0, -0.38, 0);
    hip.add(shin);

    const calf = new THREE.Mesh(
      trackGeo(new THREE.CapsuleGeometry(0.075, 0.24, 5, 10)),
      furBlueMat
    );
    calf.position.set(0, -0.18, 0);
    calf.castShadow = true;
    shin.add(calf);

    // Big adorable white cartoon cat hind paw
    const pawGroup = new THREE.Group();
    pawGroup.position.set(0, -0.39, -0.07);
    shin.add(pawGroup);

    const pawFoot = new THREE.Mesh(
      trackGeo(new THREE.CapsuleGeometry(0.082, 0.16, 6, 10)),
      whiteFurMat
    );
    pawFoot.rotation.x = Math.PI / 2;
    pawFoot.scale.set(1.18, 1.0, 0.82);
    pawFoot.castShadow = true;
    pawGroup.add(pawFoot);

    // Subtle pink paw pad underneath (visible when kicking up or jumping!)
    const pad = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.05, 8, 8)), pinkMat);
    pad.position.set(0, -0.05, 0.02);
    pad.scale.set(1.1, 0.4, 1.2);
    pawGroup.add(pad);

    return { hip, shin };
  };

  const leftLegParts = buildLeg(-1);
  const rightLegParts = buildLeg(1);

  // Powerup Auras (toggled visible when active)
  const boostAura = new THREE.Group();
  boostAura.visible = false;
  const boostRingMat = trackMat(
    new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide,
    })
  );
  for (let i = 0; i < 2; i++) {
    const ring = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(0.75 + i * 0.2, 0.035, 8, 24)),
      boostRingMat
    );
    ring.position.set(0, 1.0 + i * 0.35, 0);
    ring.rotation.x = Math.PI / 2;
    boostAura.add(ring);
  }
  group.add(boostAura);

  const magnetAuraMat = trackMat(
    new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.55,
      side: THREE.DoubleSide,
    })
  );
  const magnetAura = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.95, 0.04, 8, 28)),
    magnetAuraMat
  );
  magnetAura.position.set(0, 1.05, 0);
  magnetAura.rotation.x = Math.PI / 2;
  magnetAura.visible = false;
  group.add(magnetAura);

  return {
    group,
    hips,
    torso,
    head,
    leftEar,
    rightEar,
    leftEye: leftEyeParts.eyeGroup,
    rightEye: rightEyeParts.eyeGroup,
    leftPupil: leftEyeParts.pupil,
    rightPupil: rightEyeParts.pupil,
    leftEyelid: leftEyeParts.eyelid,
    rightEyelid: rightEyeParts.eyelid,
    leftBrow: leftEyeParts.brow,
    rightBrow: rightEyeParts.brow,
    smileMouth,
    oMouth,
    leftArm,
    rightArm,
    leftLeg: leftLegParts.hip,
    leftShin: leftLegParts.shin,
    rightLeg: rightLegParts.hip,
    rightShin: rightLegParts.shin,
    tailBase,
    tailMid,
    tailTip,
    boostAura,
    magnetAura,
    dispose: () => {
      geometries.forEach((g) => g.dispose());
      materials.forEach((m) => m.dispose());
    },
  };
}

export class AssetFactory {
  private geometries: THREE.BufferGeometry[] = [];
  private materials: THREE.Material[] = [];
  private textures: ProceduralTextureSet;

  // Shared materials
  private trackMat: THREE.MeshStandardMaterial;
  private sidewalkMat: THREE.MeshStandardMaterial;
  private buildingMats: THREE.MeshStandardMaterial[];
  private roofMat: THREE.MeshStandardMaterial;
  private gantryMetalMat: THREE.MeshStandardMaterial;
  private gantryGlowMat: THREE.MeshStandardMaterial;
  private hazardMat: THREE.MeshStandardMaterial;
  private darkMetalMat: THREE.MeshStandardMaterial;
  private redBeaconMat: THREE.MeshStandardMaterial;
  private neonSignMat: THREE.MeshStandardMaterial;
  private trainBodyMat: THREE.MeshStandardMaterial;
  private trainFrontMat: THREE.MeshStandardMaterial;
  private trainRoofMat: THREE.MeshStandardMaterial;
  private trainHeadlightMat: THREE.MeshStandardMaterial;
  private goldMat: THREE.MeshStandardMaterial;
  private magnetRedMat: THREE.MeshStandardMaterial;
  private magnetSilverMat: THREE.MeshStandardMaterial;
  private cyanGlowMat: THREE.MeshBasicMaterial;
  private boostGoldMat: THREE.MeshStandardMaterial;
  private shadowMat: THREE.MeshBasicMaterial;

  // Shared geometries
  private coinRimGeo: THREE.CylinderGeometry;
  private coinInnerGeo: THREE.CylinderGeometry;
  private shadowPlaneGeo: THREE.PlaneGeometry;

  constructor(textures: ProceduralTextureSet) {
    this.textures = textures;

    const regGeo = <T extends THREE.BufferGeometry>(g: T): T => {
      this.geometries.push(g);
      return g;
    };
    const regMat = <T extends THREE.Material>(m: T): T => {
      this.materials.push(m);
      return m;
    };

    this.trackMat = regMat(
      new THREE.MeshStandardMaterial({
        map: textures.trackMap,
        roughness: 0.85,
        metalness: 0.08,
      })
    );
    this.sidewalkMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.78, metalness: 0.05 })
    );
    this.buildingMats = textures.buildingMaps.map((map) =>
      regMat(
        new THREE.MeshStandardMaterial({
          map,
          roughness: 0.6,
          metalness: 0.15,
        })
      )
    );
    this.roofMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7, metalness: 0.25 })
    );
    this.gantryMetalMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.35, metalness: 0.75 })
    );
    this.gantryGlowMat = regMat(
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0ea5e9,
        emissiveIntensity: 0.9,
        roughness: 0.2,
      })
    );
    this.hazardMat = regMat(
      new THREE.MeshStandardMaterial({
        map: textures.hazardMap,
        roughness: 0.45,
        metalness: 0.15,
      })
    );
    this.darkMetalMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4, metalness: 0.7 })
    );
    this.redBeaconMat = regMat(
      new THREE.MeshStandardMaterial({
        color: 0xef4444,
        emissive: 0xdc2626,
        emissiveIntensity: 1.0,
        roughness: 0.25,
      })
    );
    this.neonSignMat = regMat(
      new THREE.MeshStandardMaterial({
        color: 0xf97316,
        emissive: 0xea580c,
        emissiveIntensity: 0.75,
        roughness: 0.3,
      })
    );
    this.trainBodyMat = regMat(
      new THREE.MeshStandardMaterial({
        map: textures.trainSideMap,
        roughness: 0.32,
        metalness: 0.45,
      })
    );
    this.trainFrontMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.25, metalness: 0.55 })
    );
    this.trainRoofMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0xcbd5e1, roughness: 0.5, metalness: 0.35 })
    );
    this.trainHeadlightMat = regMat(
      new THREE.MeshStandardMaterial({
        color: 0xfef9c3,
        emissive: 0xfde047,
        emissiveIntensity: 1.6,
        roughness: 0.15,
      })
    );
    this.goldMat = regMat(
      new THREE.MeshStandardMaterial({
        color: 0xfacc15,
        emissive: 0xb45309,
        emissiveIntensity: 0.25,
        metalness: 0.9,
        roughness: 0.18,
      })
    );
    this.magnetRedMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.45, roughness: 0.28 })
    );
    this.magnetSilverMat = regMat(
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.88, roughness: 0.2 })
    );
    this.cyanGlowMat = regMat(
      new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.65,
        side: THREE.DoubleSide,
      })
    );
    this.boostGoldMat = regMat(
      new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        emissive: 0xf97316,
        emissiveIntensity: 0.7,
        metalness: 0.75,
        roughness: 0.2,
      })
    );
    this.shadowMat = regMat(
      new THREE.MeshBasicMaterial({
        map: textures.contactShadowMap,
        transparent: true,
        depthWrite: false,
        opacity: 0.5,
      })
    );

    this.coinRimGeo = regGeo(new THREE.CylinderGeometry(0.42, 0.42, 0.1, 18));
    this.coinRimGeo.rotateX(Math.PI / 2);
    this.coinInnerGeo = regGeo(new THREE.CylinderGeometry(0.3, 0.3, 0.13, 14));
    this.coinInnerGeo.rotateX(Math.PI / 2);

    this.shadowPlaneGeo = regGeo(new THREE.PlaneGeometry(1.15, 1.15));
    this.shadowPlaneGeo.rotateX(-Math.PI / 2);
  }

  public createContactShadow(scale = 1): THREE.Mesh {
    const m = new THREE.Mesh(this.shadowPlaneGeo, this.shadowMat);
    m.position.y = 0.03;
    m.scale.setScalar(scale);
    return m;
  }

  public createTrackSegment(variantIndex: number): THREE.Group {
    const seg = new THREE.Group();

    // Main 3-lane track bed (12 units wide x 30 long)
    const bedGeo = new THREE.PlaneGeometry(12, TRACK_SEGMENT_LENGTH);
    bedGeo.rotateX(-Math.PI / 2);
    this.geometries.push(bedGeo);
    const bed = new THREE.Mesh(bedGeo, this.trackMat);
    bed.receiveShadow = true;
    seg.add(bed);

    // Sidewalks left & right
    const walkGeo = new THREE.BoxGeometry(4, 0.35, TRACK_SEGMENT_LENGTH);
    this.geometries.push(walkGeo);
    for (const sx of [-8, 8]) {
      const walk = new THREE.Mesh(walkGeo, this.sidewalkMat);
      walk.position.set(sx, 0.17, 0);
      walk.receiveShadow = true;
      seg.add(walk);
    }

    // Vibrant stylized city buildings flanking both sides
    const buildingPositions = [-11, 0, 11];
    for (const bz of buildingPositions) {
      for (const side of [-1, 1]) {
        const h = 9 + ((Math.abs(bz + variantIndex * 3 + side * 5) * 7) % 14);
        const w = 5.5 + ((variantIndex + Math.abs(bz)) % 3);
        const d = 8.5;
        const bGeo = new THREE.BoxGeometry(w, h, d);
        this.geometries.push(bGeo);
        const mat =
          this.buildingMats[Math.abs(variantIndex + bz + (side > 0 ? 1 : 2)) % this.buildingMats.length];
        const building = new THREE.Mesh(bGeo, mat);
        building.position.set(side * (9.5 + w / 2), h / 2, bz);
        seg.add(building);

        // Rooftop trim/penthouse
        const capGeo = new THREE.BoxGeometry(w * 0.65, 0.8, d * 0.65);
        this.geometries.push(capGeo);
        const cap = new THREE.Mesh(capGeo, this.roofMat);
        cap.position.set(side * (9.5 + w / 2), h + 0.4, bz);
        seg.add(cap);
      }
    }

    // Overhead railway signal arch / lights every segment
    const pillarGeo = new THREE.CylinderGeometry(0.14, 0.18, 6.2, 8);
    this.geometries.push(pillarGeo);
    for (const side of [-1, 1]) {
      const pillar = new THREE.Mesh(pillarGeo, this.gantryMetalMat);
      pillar.position.set(side * 6.3, 3.1, 0);
      seg.add(pillar);
    }
    const crossbarGeo = new THREE.BoxGeometry(12.8, 0.28, 0.35);
    this.geometries.push(crossbarGeo);
    const crossbar = new THREE.Mesh(crossbarGeo, this.gantryMetalMat);
    crossbar.position.set(0, 6.1, 0);
    seg.add(crossbar);

    const lampGeo = new THREE.BoxGeometry(1.1, 0.14, 0.24);
    this.geometries.push(lampGeo);
    for (const lx of LANE_POSITIONS) {
      const lamp = new THREE.Mesh(lampGeo, this.gantryGlowMat);
      lamp.position.set(lx, 5.95, 0);
      seg.add(lamp);
    }

    return seg;
  }

  public createObstacleMesh(kind: ObstacleKind): THREE.Group {
    const group = new THREE.Group();

    if (kind === 'low_barrier') {
      // Jumpable hazard barrier: height 1.05, width 2.0
      const legGeo = new THREE.CylinderGeometry(0.08, 0.1, 1.0, 8);
      const barGeo = new THREE.BoxGeometry(2.05, 0.46, 0.22);
      const beaconGeo = new THREE.SphereGeometry(0.1, 8, 8);
      this.geometries.push(legGeo, barGeo, beaconGeo);

      for (const lx of [-0.82, 0.82]) {
        const leg = new THREE.Mesh(legGeo, this.darkMetalMat);
        leg.position.set(lx, 0.5, 0);
        leg.castShadow = true;
        group.add(leg);

        const beacon = new THREE.Mesh(beaconGeo, this.redBeaconMat);
        beacon.position.set(lx, 1.04, 0);
        group.add(beacon);
      }
      const board = new THREE.Mesh(barGeo, this.hazardMat);
      board.position.set(0, 0.74, 0);
      board.castShadow = true;
      group.add(board);
    } else if (kind === 'high_barrier') {
      // Slide-under overhead gantry: clear gap from y=0 to y=1.18!
      const legGeo = new THREE.BoxGeometry(0.16, 2.55, 0.22);
      const signGeo = new THREE.BoxGeometry(2.15, 0.95, 0.26);
      const trimGeo = new THREE.BoxGeometry(1.9, 0.22, 0.3);
      this.geometries.push(legGeo, signGeo, trimGeo);

      for (const lx of [-0.98, 0.98]) {
        const leg = new THREE.Mesh(legGeo, this.gantryMetalMat);
        leg.position.set(lx, 1.275, 0);
        leg.castShadow = true;
        group.add(leg);
      }
      const sign = new THREE.Mesh(signGeo, this.hazardMat);
      sign.position.set(0, 1.72, 0);
      sign.castShadow = true;
      group.add(sign);

      const neonStrip = new THREE.Mesh(trimGeo, this.neonSignMat);
      neonStrip.position.set(0, 1.72, 0);
      group.add(neonStrip);
    } else if (kind === 'tall_barrier') {
      // Full-height blockade: width 2.05, height 2.35
      const legGeo = new THREE.BoxGeometry(0.18, 2.35, 0.32);
      const panelGeo = new THREE.BoxGeometry(2.05, 0.7, 0.28);
      const barGeo = new THREE.BoxGeometry(2.1, 0.16, 0.32);
      this.geometries.push(legGeo, panelGeo, barGeo);

      for (const lx of [-0.9, 0.9]) {
        const leg = new THREE.Mesh(legGeo, this.darkMetalMat);
        leg.position.set(lx, 1.175, 0);
        leg.castShadow = true;
        group.add(leg);
      }
      for (const py of [0.65, 1.55]) {
        const panel = new THREE.Mesh(panelGeo, this.hazardMat);
        panel.position.set(0, py, 0);
        panel.castShadow = true;
        group.add(panel);
      }
      const stopBar = new THREE.Mesh(barGeo, this.redBeaconMat);
      stopBar.position.set(0, 2.15, 0);
      group.add(stopBar);
    } else {
      // Train car (static, moving, or with front boarding ramp)
      const trainLength = 13.5;
      const bodyGeo = new THREE.BoxGeometry(2.12, 2.25, trainLength);
      const roofGeo = new THREE.BoxGeometry(1.96, 0.22, trainLength - 0.3);
      const cabGeo = new THREE.BoxGeometry(2.14, 1.85, 0.7);
      const windshieldGeo = new THREE.BoxGeometry(1.72, 0.65, 0.15);
      const headlightGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.14, 10);
      headlightGeo.rotateX(Math.PI / 2);
      const bogieGeo = new THREE.BoxGeometry(1.8, 0.32, trainLength - 1.2);
      this.geometries.push(bodyGeo, roofGeo, cabGeo, windshieldGeo, headlightGeo, bogieGeo);

      const bogie = new THREE.Mesh(bogieGeo, this.darkMetalMat);
      bogie.position.set(0, 0.16, 0);
      group.add(bogie);

      const body = new THREE.Mesh(bodyGeo, this.trainBodyMat);
      body.position.set(0, 1.42, 0);
      body.castShadow = true;
      body.receiveShadow = true;
      group.add(body);

      const roof = new THREE.Mesh(roofGeo, this.trainRoofMat);
      roof.position.set(0, 2.6, 0);
      roof.receiveShadow = true;
      group.add(roof);

      // Front nose facing player (+Z side)
      const frontZ = trainLength / 2;
      const cab = new THREE.Mesh(cabGeo, this.trainFrontMat);
      cab.position.set(0, 1.35, frontZ - 0.2);
      group.add(cab);

      const windshield = new THREE.Mesh(windshieldGeo, this.darkMetalMat);
      windshield.position.set(0, 1.75, frontZ + 0.14);
      group.add(windshield);

      for (const hx of [-0.66, 0.66]) {
        const hl = new THREE.Mesh(headlightGeo, this.trainHeadlightMat);
        hl.position.set(hx, 0.9, frontZ + 0.15);
        group.add(hl);
      }

      if (kind === 'train_ramp') {
        // Sloped front boarding ramp attached at +Z so player can run onto the roof!
        const rampLen = 4.5;
        const rampShape = new THREE.Shape();
        rampShape.moveTo(0, 0);
        rampShape.lineTo(rampLen, 0);
        rampShape.lineTo(0, TRAIN_HEIGHT);
        rampShape.closePath();

        const rampGeo = new THREE.ExtrudeGeometry(rampShape, {
          depth: 2.02,
          bevelEnabled: false,
        });
        // Rotate so X->Z (length along +Z from train front) and extrude along X centered
        rampGeo.rotateY(-Math.PI / 2);
        rampGeo.translate(1.01, 0, frontZ);
        this.geometries.push(rampGeo);

        const rampMesh = new THREE.Mesh(rampGeo, this.hazardMat);
        rampMesh.castShadow = true;
        rampMesh.receiveShadow = true;
        group.add(rampMesh);
      }
    }

    return group;
  }

  public createCoinMesh(): THREE.Group {
    const coin = new THREE.Group();
    const rim = new THREE.Mesh(this.coinRimGeo, this.goldMat);
    const inner = new THREE.Mesh(this.coinInnerGeo, this.goldMat);
    coin.add(rim, inner);
    return coin;
  }

  public createPowerupMesh(kind: PowerupKind): THREE.Group {
    const group = new THREE.Group();

    // Glowing floating halo ring
    const haloGeo = new THREE.TorusGeometry(0.62, 0.045, 8, 22);
    this.geometries.push(haloGeo);
    const halo = new THREE.Mesh(haloGeo, this.cyanGlowMat);
    group.add(halo);

    if (kind === 'magnet') {
      const arcGeo = new THREE.TorusGeometry(0.32, 0.1, 10, 18, Math.PI);
      const tipGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.24, 10);
      this.geometries.push(arcGeo, tipGeo);

      const arc = new THREE.Mesh(arcGeo, this.magnetRedMat);
      arc.position.y = 0.06;
      group.add(arc);

      for (const sx of [-0.32, 0.32]) {
        const tip = new THREE.Mesh(tipGeo, this.magnetSilverMat);
        tip.position.set(sx, -0.06, 0);
        group.add(tip);
      }
    } else {
      // Speed Boost lightning bolt crystal
      const boltShape = new THREE.Shape();
      boltShape.moveTo(0.08, 0.45);
      boltShape.lineTo(-0.22, 0.04);
      boltShape.lineTo(0.02, 0.04);
      boltShape.lineTo(-0.1, -0.45);
      boltShape.lineTo(0.24, -0.02);
      boltShape.lineTo(0.0, -0.02);
      boltShape.closePath();

      const boltGeo = new THREE.ExtrudeGeometry(boltShape, {
        depth: 0.14,
        bevelEnabled: true,
        bevelThickness: 0.03,
        bevelSize: 0.03,
        bevelSegments: 2,
      });
      boltGeo.center();
      this.geometries.push(boltGeo);

      const bolt = new THREE.Mesh(boltGeo, this.boostGoldMat);
      group.add(bolt);
    }

    return group;
  }

  public dispose(): void {
    this.geometries.forEach((g) => g.dispose());
    this.materials.forEach((m) => m.dispose());
    this.textures.dispose();
  }
}
