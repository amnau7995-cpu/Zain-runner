export type GamePhase = 'menu' | 'transitioning' | 'playing' | 'paused' | 'gameover';

export type PowerupKind = 'magnet' | 'boost';

export type ObstacleKind =
  | 'low_barrier'
  | 'high_barrier'
  | 'tall_barrier'
  | 'train_static'
  | 'train_ramp'
  | 'train_moving';

export interface ActivePowerups {
  magnetRemaining: number;
  magnetDuration: number;
  boostRemaining: number;
  boostDuration: number;
}

export interface GameHUDState {
  phase: GamePhase;
  score: number;
  bestScore: number;
  coins: number;
  distance: number;
  speedMultiplier: number;
  isNewBest: boolean;
  activePowerups: ActivePowerups;
  webglLost: boolean;
}

export interface RunnerEngineCallbacks {
  onStateChange: (state: GameHUDState) => void;
}
