# Converting Zain Runner to an Android APK with Capacitor

This project is pre-configured with `capacitor.config.json` (`appId: com.zain.runner`, `appName: Zain Runner`, `webDir: dist`) and mobile-optimized touch/safe-area styling.

## Build Steps

1. Install Capacitor CLI and Android platform locally:
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   ```
2. Build the production web bundle:
   ```bash
   npm run build
   ```
3. Add the Android project and sync assets:
   ```bash
   npx cap add android
   npx cap sync android
   ```
4. Open in Android Studio to build or run on an Android device / generate a signed APK:
   ```bash
   npx cap open android
   ```
